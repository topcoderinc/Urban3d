# -*- coding: utf-8 -*-
from os import path, listdir, mkdir
import numpy as np
np.random.seed(1)
import random
random.seed(1)
import timeit
import cv2
from tqdm import tqdm
from skimage import measure
from multiprocessing import Pool
import sys
import lightgbm as lgb
from sklearn.model_selection import KFold
from sklearn.neighbors import KDTree
from skimage.morphology import watershed

train_folder = r'training'
predicted_folder = r'train_pred'
masks_folder = r'masks_fixed'

lgbm_models_folder = 'lgbm_models'

pixels_threshold = 70
sep_count = 2
sep_thresholds = [130, 130]

def rlencode(x, dropna=False):
    """
    Run length encoding.
    Based on http://stackoverflow.com/a/32681075, which is based on the rle
    function from R.

    Parameters
    ----------
    x : 1D array_like
        Input array to encode
    dropna: bool, optional
        Drop all runs of NaNs.

    Returns
    -------
    start positions, run lengths, run values

    """
    where = np.flatnonzero
    x = np.asarray(x)
    n = len(x)
    if n == 0:
        return (np.array([], dtype=int),
                np.array([], dtype=int),
                np.array([], dtype=x.dtype))

    starts = np.r_[0, where(~np.isclose(x[1:], x[:-1], equal_nan=True)) + 1]
    lengths = np.diff(np.r_[starts, n])
    values = x[starts]

    if dropna:
        mask = ~np.isnan(values)
        starts, lengths, values = starts[mask], lengths[mask], values[mask]

    return starts, lengths, values

def rldecode(starts, lengths, values, minlength=None):
    """
    Decode a run-length encoding of a 1D array.

    Parameters
    ----------
    starts, lengths, values : 1D array_like
        The run-length encoding.
    minlength : int, optional
        Minimum length of the output array.

    Returns
    -------
    1D array. Missing data will be filled with NaNs.

    """
    starts, lengths, values = map(np.asarray, (starts, lengths, values))
    ends = starts + lengths
    n = ends[-1]
    if minlength is not None:
        n = max(minlength, n)
    x = np.full(n, np.nan)
    for lo, hi, val in zip(starts, ends, values):
        x[lo:hi] = val
    return x


def rle_to_string(rle):
    (starts, lengths, values) = rle
    items = []
    for i in range(len(starts)):
        items.append(str(values[i]))
        items.append(str(lengths[i]))
    return ','.join(items)

def get_inputs(filename, pred_folder, img_folder, truth_folder=None):
    inputs = []    
    pred = cv2.imread(path.join(pred_folder, filename), cv2.IMREAD_UNCHANGED)
    
    pred_msk = 1 * (pred > pixels_threshold)
    pred_labels = measure.label(pred_msk, neighbors=4, background=0)
    pred_props = measure.regionprops(pred_labels)
    
    img = cv2.imread(path.join(img_folder, filename.replace('_RGB.png', '_RGB.tif')), cv2.IMREAD_UNCHANGED)
    dsm = cv2.imread(path.join(img_folder, filename.replace('_RGB.png', '_DSM.tif')), cv2.IMREAD_UNCHANGED)
    dtm = cv2.imread(path.join(img_folder, filename.replace('_RGB.png', '_DTM.tif')), cv2.IMREAD_UNCHANGED)
    diff = dsm - dtm
            
    coords = [pr.centroid for pr in pred_props]
    t = KDTree(coords)
    neighbors100 = t.query_radius(coords, r=100)
    neighbors200 = t.query_radius(coords, r=200)
    neighbors300 = t.query_radius(coords, r=300)
    neighbors400 = t.query_radius(coords, r=400)
    med_area = np.median(np.asarray([pr.area for pr in pred_props]))
    
    lvl2_labels = [np.zeros_like(pred_labels, dtype=np.int) for i in range(sep_count)]
    
    separated_regions = [[] for i in range(sep_count)]
    main_regions = [[] for i in range(sep_count)]
    
    for i in range(len(pred_props)):
        msk_reg = pred_labels[pred_props[i].bbox[0]:pred_props[i].bbox[2], pred_props[i].bbox[1]:pred_props[i].bbox[3]] == i+1
        pred_reg = pred[pred_props[i].bbox[0]:pred_props[i].bbox[2], pred_props[i].bbox[1]:pred_props[i].bbox[3]]
        rgb_reg = img[pred_props[i].bbox[0]:pred_props[i].bbox[2], pred_props[i].bbox[1]:pred_props[i].bbox[3]]
        diff_reg = diff[pred_props[i].bbox[0]:pred_props[i].bbox[2], pred_props[i].bbox[1]:pred_props[i].bbox[3]]
        
        contours = cv2.findContours((msk_reg * 255).astype(dtype=np.uint8), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        if len(contours[1]) > 0:
            cnt = contours[1][0]
            min_area_rect = cv2.minAreaRect(cnt)
        
        inp = []
        inp.append(pred_props[i].area)
        inp.append(0)
        if len(contours[1]) > 0:
            inp.append(cv2.isContourConvex(cnt) * 1.0)
            inp.append(min(min_area_rect[1]))
            inp.append(max(min_area_rect[1]))
            if max(min_area_rect[1]) > 0:
                inp.append(min(min_area_rect[1]) / max(min_area_rect[1]))
            else:
                inp.append(0)
            inp.append(min_area_rect[2])
        else:
            inp.append(0)
            inp.append(0)
            inp.append(0)
            inp.append(0)
            inp.append(0)
        inp.append(pred_props[i].convex_area)
        inp.append(pred_props[i].solidity)
        inp.append(pred_props[i].eccentricity)
        inp.append(pred_props[i].extent)
        inp.append(pred_props[i].perimeter)
        inp.append(pred_props[i].major_axis_length)
        inp.append(pred_props[i].minor_axis_length)
        if(pred_props[i].minor_axis_length > 0):
            inp.append(pred_props[i].minor_axis_length / pred_props[i].major_axis_length)
        else:
            inp.append(0)
        
        diff_values = diff_reg[msk_reg]
        rgb_values = rgb_reg[msk_reg]
        pred_values = pred_reg[msk_reg]
        
        inp.append(pred_values.mean())
        inp.append(diff_values.mean())
        inp.append(rgb_values[:, 0].mean())
        inp.append(rgb_values[:, 1].mean())
        inp.append(rgb_values[:, 2].mean())
        inp.append(pred_values.std())
        inp.append(diff_values.std())
        inp.append(rgb_values[:, 0].std())
        inp.append(rgb_values[:, 1].std())
        inp.append(rgb_values[:, 2].std())
#        
        inp.append(neighbors100[i].shape[0])
        median_area = med_area
        if neighbors100[i].shape[0] > 0:
            neighbors_areas = np.asarray([pred_props[j].area for j in neighbors100[i]])
            median_area = np.median(neighbors_areas)
        inp.append(median_area)
        inp.append(pred_props[i].area / median_area)
        
        inp.append(neighbors200[i].shape[0])
        median_area = med_area
        if neighbors200[i].shape[0] > 0:
            neighbors_areas = np.asarray([pred_props[j].area for j in neighbors200[i]])
            median_area = np.median(neighbors_areas)
        inp.append(median_area)
        inp.append(pred_props[i].area / median_area)
        
        inp.append(neighbors300[i].shape[0])
        median_area = med_area
        if neighbors300[i].shape[0] > 0:
            neighbors_areas = np.asarray([pred_props[j].area for j in neighbors300[i]])
            median_area = np.median(neighbors_areas)
        inp.append(median_area)
        inp.append(pred_props[i].area / median_area)
        
        inp.append(neighbors400[i].shape[0])
        median_area = med_area
        if neighbors400[i].shape[0] > 0:
            neighbors_areas = np.asarray([pred_props[j].area for j in neighbors400[i]])
            median_area = np.median(neighbors_areas)
        inp.append(median_area)
        inp.append(pred_props[i].area / median_area)
        
        
        bst_j = 0
        pred_reg[~msk_reg] = 0
        max_regs = 1
        for j in range(1, sep_count+1):
            sep_regs = []
            if bst_j > 0:
                separated_regions[j-1].append(sep_regs)
                continue
            pred_reg2 = 255 * (pred_reg > sep_thresholds[j-1])
            pred_reg2 = pred_reg2.astype(np.uint8)
            if j > sep_count-1:
                kernel = np.ones((3, 3), np.uint8)
                pred_reg2 = cv2.erode(pred_reg2, kernel, iterations = 3)
            lbls = measure.label(pred_reg2, neighbors=4, background=False)
            num_regs = lbls.max()
            if num_regs > 1:
                bst_j = j
                max_regs = num_regs
            if num_regs > 1 or (j < sep_count and num_regs > 0):
                lbls = lbls.astype(np.int32)
                if num_regs > 1:
                    labels_ws = watershed(msk_reg, lbls, mask=msk_reg)
                else:
                    labels_ws = lbls
                start_num = len(main_regions[j-1])
                labels_ws += start_num
                labels_ws[labels_ws == start_num] = 0
                for k in range(num_regs):
                    sep_regs.append(k+start_num)
                    main_regions[j-1].append(i)
                lvl2_labels[j-1][pred_props[i].bbox[0]:pred_props[i].bbox[2], pred_props[i].bbox[1]:pred_props[i].bbox[3]] += labels_ws
            separated_regions[j-1].append(sep_regs)
               
        inp.append(bst_j)
        inp.append(max_regs)
        inp.append(1)
        inp.append(0)
        
        inputs.append(np.asarray(inp))
    inputs = np.asarray(inputs)
    all_sep_props = []
    all_sep_inputs = []
    for j in range(sep_count):
        inputs_lvl2 = []
        pred_props2 = measure.regionprops(lvl2_labels[j])
        for i in range(len(pred_props2)):
            msk_reg = lvl2_labels[j][pred_props2[i].bbox[0]:pred_props2[i].bbox[2], pred_props2[i].bbox[1]:pred_props2[i].bbox[3]] == i+1
            pred_reg = pred[pred_props2[i].bbox[0]:pred_props2[i].bbox[2], pred_props2[i].bbox[1]:pred_props2[i].bbox[3]]
            rgb_reg = img[pred_props2[i].bbox[0]:pred_props2[i].bbox[2], pred_props2[i].bbox[1]:pred_props2[i].bbox[3]]
            diff_reg = diff[pred_props2[i].bbox[0]:pred_props2[i].bbox[2], pred_props2[i].bbox[1]:pred_props2[i].bbox[3]]
            
            contours = cv2.findContours((msk_reg * 255).astype(dtype=np.uint8), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
            if len(contours[1]) > 0:
                cnt = contours[1][0]
                min_area_rect = cv2.minAreaRect(cnt)
        
            inp = []
            inp.append(pred_props2[i].area)
            main_area = inputs[main_regions[j][i]][0]
            inp.append(pred_props2[i].area / main_area)
            if len(contours[1]) > 0:
                inp.append(cv2.isContourConvex(cnt) * 1.0)
                inp.append(min(min_area_rect[1]))
                inp.append(max(min_area_rect[1]))
                if max(min_area_rect[1]) > 0:
                    inp.append(min(min_area_rect[1]) / max(min_area_rect[1]))
                else:
                    inp.append(0)
                inp.append(min_area_rect[2])
            else:
                inp.append(0)
                inp.append(0)
                inp.append(0)
                inp.append(0)
                inp.append(0)
            inp.append(pred_props2[i].convex_area)
            inp.append(pred_props2[i].solidity)
            inp.append(pred_props2[i].eccentricity)
            inp.append(pred_props2[i].extent)
            inp.append(pred_props2[i].perimeter)
            inp.append(pred_props2[i].major_axis_length)
            inp.append(pred_props2[i].minor_axis_length)
            if(pred_props2[i].minor_axis_length > 0):
                inp.append(pred_props2[i].minor_axis_length / pred_props2[i].major_axis_length)
            else:
                inp.append(0)
            
            diff_values = diff_reg[msk_reg]
            rgb_values = rgb_reg[msk_reg]
            pred_values = pred_reg[msk_reg]
            
            inp.append(pred_values.mean())
            inp.append(diff_values.mean())
            inp.append(rgb_values[:, 0].mean())
            inp.append(rgb_values[:, 1].mean())
            inp.append(rgb_values[:, 2].mean())
            inp.append(pred_values.std())
            inp.append(diff_values.std())
            inp.append(rgb_values[:, 0].std())
            inp.append(rgb_values[:, 1].std())
            inp.append(rgb_values[:, 2].std())
    #        
            inp.append(inputs[main_regions[j][i]][-16])
            median_area = inputs[main_regions[j][i]][-15]
            inp.append(median_area)
            inp.append(pred_props2[i].area / median_area)
            
            inp.append(inputs[main_regions[j][i]][-13])
            median_area = inputs[main_regions[j][i]][-12]
            inp.append(median_area)
            inp.append(pred_props2[i].area / median_area)
            
            inp.append(inputs[main_regions[j][i]][-10])
            median_area = inputs[main_regions[j][i]][-9]
            inp.append(median_area)
            inp.append(pred_props2[i].area / median_area)
            
            inp.append(inputs[main_regions[j][i]][-7])
            median_area = inputs[main_regions[j][i]][-6]
            inp.append(median_area)
            inp.append(pred_props2[i].area / median_area)
            
            bst_j = inputs[main_regions[j][i]][-4]
            max_regs = inputs[main_regions[j][i]][-3]
        
            inp.append(bst_j)
            inp.append(max_regs)
            inp.append(len(separated_regions[j][main_regions[j][i]]))
            inp.append(j+1)
            
            inputs_lvl2.append(np.asarray(inp))
        all_sep_props.append(pred_props2)
        inputs_lvl2 = np.asarray(inputs_lvl2)
        all_sep_inputs.append(inputs_lvl2)
        
    if truth_folder is None:
        return inputs, pred_labels, all_sep_inputs, lvl2_labels, separated_regions
    else:
        outputs = []
        
        truth_msk = cv2.imread(path.join(truth_folder, filename), cv2.IMREAD_UNCHANGED)
        truth_msk = 1 * (truth_msk > pixels_threshold)
        truth_labels = measure.label(truth_msk, neighbors=4, background=0)
        truth_props = measure.regionprops(truth_labels)
        
        m = np.zeros((len(pred_props), len(truth_props)))
        
        for x in range(pred_labels.shape[1]):
            for y in range(pred_labels.shape[0]):
                if pred_labels[y, x] > 0 and truth_labels[y, x] > 0:
                    m[pred_labels[y, x]-1, truth_labels[y, x]-1] += 1
        
        truth_used = set([])
        for i in range(len(pred_props)): 
            tp = 0
            for j in range(len(truth_props)):
                if m[i, j] > 0:
                    iou = m[i, j] / (pred_props[i].area + truth_props[j].area - m[i, j])
                    if iou > 0.45:
                        tp = 1
                        truth_used.add(j)
            outputs.append(tp)
            
        outputs = np.asarray(outputs)
        fn = len(truth_props) - len(truth_used)
        
        all_sep_outputs = []
        
        for k in range(sep_count):
            pred_props2 = all_sep_props[k]
            outputs_lvl2 = []
            m2 = np.zeros((len(pred_props2), len(truth_props)))
            
            for x in range(lvl2_labels[k].shape[1]):
                for y in range(lvl2_labels[k].shape[0]):
                    if lvl2_labels[k][y, x] > 0 and truth_labels[y, x] > 0:
                        m2[lvl2_labels[k][y, x]-1, truth_labels[y, x]-1] += 1
            
            truth_used2 = set([])
            for i in range(len(pred_props2)): 
                tp = 0
                for j in range(len(truth_props)):
                    if m2[i, j] > 0:
                        iou = m2[i, j] / (pred_props2[i].area + truth_props[j].area - m2[i, j])
                        if iou > 0.45:
                            tp = 1
                            truth_used2.add(j)
                outputs_lvl2.append(tp)
                
            outputs_lvl2 = np.asarray(outputs_lvl2)
            all_sep_outputs.append(outputs_lvl2)
        
        return inputs, pred_labels, all_sep_inputs, lvl2_labels, separated_regions, outputs, all_sep_outputs, fn
            
if __name__ == '__main__':
    t0 = timeit.default_timer()
    
    if len(sys.argv) > 1:
        train_folder = sys.argv[1]     
    
    if not path.isdir(lgbm_models_folder):
        mkdir(lgbm_models_folder)
        
    all_files = []
    truth_files = []
    inputs = []
    outputs = []
    inputs2 = []
    outputs2 = []
    labels = []
    labels2 = []
    separated_regions = []
    fns = []
    paramss = []
    
    for f in tqdm(sorted(listdir(masks_folder))):
        if path.isfile(path.join(masks_folder, f)) and '_RGB.png' in f:
            all_files.append(path.join(predicted_folder, f))
            truth_files.append(path.join(masks_folder, f))
            paramss.append((f, predicted_folder, train_folder, masks_folder))

    with Pool(processes=4) as pool:
        results = pool.starmap(get_inputs, paramss)
    for i in range(len(results)):
        inp, lbl, inp2, lbl2, sep_regs, otp, otp2, fn = results[i]
        inputs.append(inp)
        outputs.append(otp)
        inputs2.append(inp2)
        outputs2.append(otp2)
        labels.append(lbl)
        labels2.append(lbl2)
        separated_regions.append(sep_regs)
        fns.append(fn)
    
    num_split_iters = 100
    folds_count = 2
    gbm_models = []
    
    train_pred = [np.zeros_like(otp) for otp in outputs]
    train_pred2 = [[np.zeros_like(otp) for otp in otp2] for otp2 in  outputs2]
    
    for it in range(num_split_iters):
        kf = KFold(n_splits=folds_count, random_state=it+1, shuffle=True)
        it2 = -1
        for train_idxs, test_idxs in kf.split(all_files):
            it2 += 1
            print('training lgb', it, it2)
            random.seed(it*1000+it2)
            np.random.seed(it*1000+it2)
            train_inp = None
            train_otp = None
            test_inp = None 
            test_otp = None
            for i in train_idxs:
                if train_inp is None:
                    if inputs[i].shape[0] > 0:
                        train_inp = inputs[i].copy()
                        train_otp = outputs[i].copy()
                    for j in range(len(inputs2[i])):
                        if inputs2[i][j].shape[0] > 0:
                            train_inp = np.concatenate((train_inp, inputs2[i][j]), axis=0)
                            train_otp = np.concatenate((train_otp, outputs2[i][j]), axis=0)
                else:
                    if inputs[i].shape[0] > 0:
                        train_inp = np.concatenate((train_inp, inputs[i]), axis=0)
                        train_otp = np.concatenate((train_otp, outputs[i]), axis=0)
                    for j in range(len(inputs2[i])):
                        if inputs2[i][j].shape[0] > 0:
                            train_inp = np.concatenate((train_inp, inputs2[i][j]), axis=0)
                            train_otp = np.concatenate((train_otp, outputs2[i][j]), axis=0)
            for i in test_idxs:
                if test_inp is None:
                    if inputs[i].shape[0] > 0:
                        test_inp = inputs[i].copy()
                        test_otp = outputs[i].copy()
                    for j in range(len(inputs2[i])):
                        if inputs2[i][j].shape[0] > 0:
                            test_inp = np.concatenate((test_inp, inputs2[i][j]), axis=0)
                            test_otp = np.concatenate((test_otp, outputs2[i][j]), axis=0)
                else:
                    if inputs[i].shape[0] > 0:
                        test_inp = np.concatenate((test_inp, inputs[i]), axis=0)
                        test_otp = np.concatenate((test_otp, outputs[i]), axis=0)
                    for j in range(len(inputs2[i])):
                        if inputs2[i][j].shape[0] > 0:
                            test_inp = np.concatenate((test_inp, inputs2[i][j]), axis=0)
                            test_otp = np.concatenate((test_otp, outputs2[i][j]), axis=0)
    
            lgb_train = lgb.Dataset(train_inp, train_otp)
            lgb_eval = lgb.Dataset(test_inp, test_otp, reference=lgb_train)
            
            lr = random.random()*0.15 + 0.05
            ff = random.random()*0.5 + 0.5
            nl = random.randint(6, 50)
            
            params = {
                'task': 'train',
                'boosting_type': 'gbdt',
                'objective': 'binary',
                'metric': {'binary_logloss'},
                'num_leaves': nl,
                'learning_rate': lr,
                'feature_fraction': ff,
                'bagging_fraction': 0.95,
                'bagging_freq': 1,
                'verbosity': 0,
                'seed': it*1000+it2
            }

            gbm = lgb.train(params,
                            lgb_train,
                            num_boost_round=300,
                            valid_sets=lgb_eval,
                            early_stopping_rounds=5)
            
            gbm.free_dataset()
            gbm_models.append(gbm)
            gbm.save_model(path.join(lgbm_models_folder, 'gbm_model_{0}_{1}.txt'.format(it, it2)))
            
            for i in test_idxs:
                if train_pred[i].shape[0] > 0:
                    train_pred[i] = train_pred[i] + gbm.predict(inputs[i])
                for j in range(len(train_pred2[i])):
                    if train_pred2[i][j].shape[0] > 0:
                        train_pred2[i][j] = train_pred2[i][j] + gbm.predict(inputs2[i][j])
    
    for i in range(len(inputs)):
        if train_pred[i].shape[0] > 0:
            train_pred[i] = train_pred[i] / num_split_iters
        for j in range(len(train_pred2[i])):
            if train_pred2[i][j].shape[0] > 0:
                train_pred2[i][j] = train_pred2[i][j] / num_split_iters
    
    
    pred_merged = []
    outputs_merged = []    
    pos_pos = 0
    pos_neg = 0
    neg_pos = 0
    neg_neg = 0
    replaced = 0
    not_replaced = 0
    bst_k = np.zeros((sep_count+1))
    for i in range(len(inputs)):
        pr = []
        otp = []
        for j in range(train_pred[i].shape[0]):
            max_sep = -1
            max_pr = train_pred[i][j]
            for k in range(len(separated_regions[i])):
                if len(separated_regions[i][k][j]) > 0:
                    pred_lvl2 = train_pred2[i][k][separated_regions[i][k][j]]
                    if pred_lvl2.max() > max_pr:
                        max_sep = k
                        max_pr = pred_lvl2.max()
            if max_sep >= 0:
                pred_lvl2 = train_pred2[i][max_sep][separated_regions[i][max_sep][j]]
                otp_lvl2 = outputs2[i][max_sep][separated_regions[i][max_sep][j]]
                pr.extend(pred_lvl2)
                otp.extend(otp_lvl2)
                replaced += 1
                if outputs[i][j] == 1:
                    if otp_lvl2.max() == 1:
                        pos_pos += 1
                    else:
                        pos_neg += 1
                else:
                    if otp_lvl2.max() == 1:
                        neg_pos += 1
                    else:
                        neg_neg += 1                
            else:
                pr.append(train_pred[i][j])
                otp.append(outputs[i][j])
                not_replaced += 1
            bst_k[max_sep+1] += 1
                
        pred_merged.append(np.asarray(pr))
        outputs_merged.append(np.asarray(otp))
        fns[i] = fns[i] - (outputs_merged[i].sum() - outputs[i].sum())
    print('replaced', replaced, 'not_replaced', not_replaced, 'pos_pos', pos_pos, 'pos_neg', pos_neg, 'neg_pos', neg_pos, 'neg_neg', neg_neg)
    print(bst_k)
    
    thr = 0
    best_thr = 0
    best_sc = 0
    while thr < 1:
        tot_score = 0
        for i in range(len(inputs)):
            pr = 1 * (pred_merged[i] > thr)
            tp = (outputs_merged[i] * pr).sum()
            fp = pr.sum() - tp
            fn = outputs_merged[i].sum() - tp
            fn += fns[i]
            precision = tp / (tp + fp)
            recall = tp / (tp + fn)
            f_score = 0
            if precision > 0 and recall > 0:
                f_score = 2 * precision * recall / (precision + recall)
            tot_score += f_score
        tot_score /= len(inputs)
        if tot_score > best_sc:
            best_thr = thr
            best_sc = tot_score
            print('best_sc', best_sc, 'best_thr', best_thr)
        thr += 0.0005
        
    
    bst_k = np.zeros((sep_count+1))
    f_sub = open('train_submission.txt', 'w')
    removed = 0
    replaced = 0
    total_cnt = 0
    im_idx = 0
    for f in tqdm(sorted(listdir(predicted_folder))):
        if path.isfile(path.join(predicted_folder, f)) and '_RGB.png' in f:
            tile_id = f.split('_RGB')[0]
            
            pred_labels = np.zeros_like(labels[im_idx], dtype=np.int)
            
            clr = 1
            
            for i in range(train_pred[im_idx].shape[0]):
                max_sep = -1
                max_pr = train_pred[im_idx][i]
                for k in range(len(separated_regions[im_idx])):
                    if len(separated_regions[im_idx][k][i]) > 0:
                        pred_lvl2 = train_pred2[im_idx][k][separated_regions[im_idx][k][i]]
                        if pred_lvl2.max() > max_pr:
                            max_sep = k
                            max_pr = pred_lvl2.max()
                            
                if max_sep >= 0:
                    pred_lvl2 = train_pred2[im_idx][max_sep][separated_regions[im_idx][max_sep][i]]
                    replaced += 1
                    for j in separated_regions[im_idx][max_sep][i]:
                        if train_pred2[im_idx][max_sep][j] > best_thr:
                            pred_labels[labels2[im_idx][max_sep] == j+1] = clr
                            clr += 1
                        else:
                            removed += 1
                else:
                    if train_pred[im_idx][i] > best_thr:
                        pred_labels[labels[im_idx] == i+1] = clr
                        clr += 1
                    else:
                        removed += 1
                bst_k[max_sep+1] += 1
            total_cnt += pred_labels.max()
    
            rle_str = rle_to_string(rlencode(pred_labels.flatten()))
            f_sub.write("{0}\n{1},{2}\n{3}\n".format(tile_id, pred_labels.shape[1], pred_labels.shape[0], rle_str))
            im_idx += 1
    f_sub.close()
    
    print('total_cnt', total_cnt, 'removed', removed, 'replaced', replaced)
    print(bst_k)
    
    elapsed = timeit.default_timer() - t0
    print('Time: {:.3f} min'.format(elapsed / 60))