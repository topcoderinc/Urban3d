# -*- coding: utf-8 -*-
from os import path, listdir, mkdir
import numpy as np
np.random.seed(1)
import random
random.seed(1)
import pandas as pd
import timeit
import cv2
from tqdm import tqdm
from skimage import measure
from multiprocessing import Pool
import sys

train_folder = r'd:\TopCoder\training'
predicted_folder = r'c:\projects\TopCoder\UrbanMapper3D\train_pred'
masks_folder = r'c:\projects\TopCoder\UrbanMapper3D\masks_fixed'

def process_file(f):
    gtl = cv2.imread(path.join(train_folder, f), cv2.IMREAD_UNCHANGED)
    msk = (gtl == 6) | (gtl == 65)
    gti = measure.label(msk, background=0)
    props = measure.regionprops(gti)
    
#            gti = cv2.imread(path.join(train_folder, f), cv2.IMREAD_UNCHANGED)
    pred = cv2.imread(path.join(predicted_folder, f.replace('_GTL.tif', '_RGB.png')), cv2.IMREAD_UNCHANGED)
    dsm = cv2.imread(path.join(train_folder, f.replace('_GTL', '_DSM')), cv2.IMREAD_UNCHANGED)
    
    pred = (pred > 127) * 1
    msk = np.zeros(pred.shape, dtype=np.uint8)
    removed = 0
    removed_on_black = 0
    for i in np.unique(gti):
        if i == 0:
            continue
        cnt = pred[gti == i].sum()
        if cnt < 10:
            removed += 1
            gti[gti == i] = 0
        elif gtl[props[i-1].coords[0, 0], props[i-1].coords[0, 1]] == 65:
            tmp = dsm[props[i-1].bbox[0]:props[i-1].bbox[2]+1, props[i-1].bbox[1]:props[i-1].bbox[3]+1]
            if tmp[tmp < -10000].shape[0] > 0:
                removed_on_black += 1
                gti[gti == i] = 0
    
    pixels_ignored = 0
    sz = 6
    for x in range(gti.shape[1]):
        for y in range(gti.shape[0]):
            if (gti[y, x] > 0):
                if (gti[max(0, y - sz), x] == 0 or gti[max(0, y - sz), x] == gti[y, x]) \
                    and (gti[min(gti.shape[0]-1, y + sz), x] == 0 or gti[min(gti.shape[0]-1, y + sz), x] == gti[y, x]) \
                    and (gti[y, max(0, x - sz)] == 0 or gti[y, max(0, x - sz)] == gti[y, x]) \
                    and (gti[y, min(gti.shape[1]-1, x + sz)] == 0 or gti[y, min(gti.shape[1]-1, x + sz)] == gti[y, x]) \
                    and (gti[max(0, y - sz), max(0, x - sz)] == 0 or gti[max(0, y - sz), max(0, x - sz)] == gti[y, x]) \
                    and (gti[min(gti.shape[0]-1, y + sz), min(gti.shape[1]-1, x + sz)] == 0 or gti[min(gti.shape[0]-1, y + sz), min(gti.shape[1]-1, x + sz)] == gti[y, x]) \
                    and (gti[max(0, y - sz), min(gti.shape[1]-1, x + sz)] == 0 or gti[max(0, y - sz), min(gti.shape[1]-1, x + sz)] == gti[y, x]) \
                    and (gti[min(gti.shape[0]-1, y + sz), max(0, x - sz)] == 0 or gti[min(gti.shape[0]-1, y + sz), max(0, x - sz)] == gti[y, x]):
                    msk[y, x] = 255
                else:
                    pixels_ignored += 1
    print(f, 'removed:', removed, 'removed_on_black:', removed_on_black, 'pixels_ignored:', pixels_ignored)
    sys.stdout.flush()
    cv2.imwrite(path.join(masks_folder, f.replace('_GTL.tif', '_RGB.png')), msk, [cv2.IMWRITE_PNG_COMPRESSION, 9])
            
if __name__ == '__main__':
    t0 = timeit.default_timer()
    
    if not path.isdir(masks_folder):
        mkdir(masks_folder)
    
    all_files = []
    for f in sorted(listdir(train_folder)):
        if path.isfile(path.join(train_folder, f)) and '_GTL.tif' in f:
            all_files.append(f)
            
    with Pool(processes=4) as pool:
        results = pool.map(process_file, all_files)
    
    elapsed = timeit.default_timer() - t0
    print('Time: {:.3f} min'.format(elapsed / 60))