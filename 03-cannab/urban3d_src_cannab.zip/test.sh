python predict_full_image.py $2 $1 
python predict_classifier.py $2 $3 