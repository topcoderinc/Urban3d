# -*- coding: utf-8 -*-
import os
import sys
#n_fold = -1

#if len(sys.argv) > 1:
#    os.environ['CUDA_VISIBLE_DEVICES'] = sys.argv[1]
#    n_fold = int(sys.argv[1])

from os import path, listdir, mkdir
import numpy as np
np.random.seed(1)
import random
random.seed(1)
import timeit
import cv2
from tqdm import tqdm
from train_resnet import preprocess_input_keras
from models import get_resnet_unet, get_vgg_unet
from linknet import get_linknet

models_folder = 'nn_models'
data_folder = 'testing'
pred_folder = 'test_pred'

step_sz = (2048, 2048)

def do_clahe(img):
    clahe = cv2.createCLAHE(clipLimit=1.0, tileGridSize=(21, 21))
    cl1 = img.copy()
    cl1[:, :, 0] = clahe.apply(img[:, :, 0])
    cl1[:, :, 1] = clahe.apply(img[:, :, 1])
    cl1[:, :, 2] = clahe.apply(img[:, :, 2])
    return cl1

def predict_image(in_folder, out_folder, image_name, models, clahe_models):
    img = cv2.imread(path.join(in_folder, image_name), cv2.IMREAD_UNCHANGED)
    img_clahe = do_clahe(img)
    dsm = cv2.imread(path.join(in_folder, image_name.replace('_RGB', '_DSM')), cv2.IMREAD_UNCHANGED)
    dtm = cv2.imread(path.join(in_folder, image_name.replace('_RGB', '_DTM')), cv2.IMREAD_UNCHANGED)
    diff = dsm - dtm
            
    inp = preprocess_input_keras(img[np.newaxis, ...])
    inp_clahe = preprocess_input_keras(img_clahe[np.newaxis, ...])
    inp2 = diff[np.newaxis, ..., np.newaxis]
    
    mask = np.zeros((img.shape[:2]))
    
    for model in models:
        mask += model.predict([inp, inp2], batch_size=1)[0, ..., 0]
    for model in clahe_models:
        mask += model.predict([inp_clahe, inp2], batch_size=1)[0, ..., 0]
            
    inp = inp[:, :, ::-1, ...]
    inp_clahe = inp_clahe[:, :, ::-1, ...]
    inp2 = inp2[:, :, ::-1, ...]
    
    for model in models:
        pred = model.predict([inp, inp2], batch_size=1)
        mask += pred[0, :, ::-1, 0]

    for model in clahe_models:
        pred = model.predict([inp_clahe, inp2], batch_size=1)
        mask += pred[0, :, ::-1, 0]
            
    mask = mask / (2*(len(models) + len(clahe_models)))

    mask = mask * 255
    mask = mask.astype('uint8')
    cv2.imwrite(path.join(out_folder, image_name.replace('.tif', '.png')), mask, [cv2.IMWRITE_PNG_COMPRESSION, 9])
    

if __name__ == '__main__':
    t0 = timeit.default_timer()
    
    if len(sys.argv) > 1:
        data_folder = sys.argv[1]
        
    if not path.isdir(pred_folder):
        mkdir(pred_folder)
        
    models = []
    model = get_resnet_unet(step_sz)
    model.load_weights(path.join(models_folder, 'resnet_model_weights_0.h5'))
    models.append(model)
    model = get_resnet_unet(step_sz)
    model.load_weights(path.join(models_folder, 'resnet_model_weights_1.h5'))
    models.append(model)
    model = get_resnet_unet(step_sz)
    model.load_weights(path.join(models_folder, 'resnet_model_weights_2.h5'))
    models.append(model)
    model = get_resnet_unet(step_sz)
    model.load_weights(path.join(models_folder, 'resnet_model_weights_3.h5'))
    models.append(model)
    
    models_resnet_clahe = []
    model = get_resnet_unet(step_sz)
    model.load_weights(path.join(models_folder, 'resnet_clahe_model_weights_0.h5'))
    models_resnet_clahe.append(model)
    model = get_resnet_unet(step_sz)
    model.load_weights(path.join(models_folder, 'resnet_clahe_model_weights_1.h5'))
    models_resnet_clahe.append(model)
    model = get_resnet_unet(step_sz)
    model.load_weights(path.join(models_folder, 'resnet_clahe_model_weights_2.h5'))
    models_resnet_clahe.append(model)
    model = get_resnet_unet(step_sz)
    model.load_weights(path.join(models_folder, 'resnet_clahe_model_weights_3.h5'))
    models_resnet_clahe.append(model)
    
    models_vgg = []
    model = get_vgg_unet(step_sz, weights=None)
    model.load_weights(path.join(models_folder, 'vgg_model_weights_0.h5'))
    models_vgg.append(model)
    model = get_vgg_unet(step_sz, weights=None)
    model.load_weights(path.join(models_folder, 'vgg_model_weights_1.h5'))
    models_vgg.append(model)
    model = get_vgg_unet(step_sz, weights=None)
    model.load_weights(path.join(models_folder, 'vgg_model_weights_2.h5'))
    models_vgg.append(model)
    model = get_vgg_unet(step_sz, weights=None)
    model.load_weights(path.join(models_folder, 'vgg_model_weights_3.h5'))
    models_vgg.append(model)
    
    models_vgg_clahe = []
    model = get_vgg_unet(step_sz, weights=None)
    model.load_weights(path.join(models_folder, 'vgg_clahe_model_weights_0.h5'))
    models_vgg_clahe.append(model)
    model = get_vgg_unet(step_sz, weights=None)
    model.load_weights(path.join(models_folder, 'vgg_clahe_model_weights_1.h5'))
    models_vgg_clahe.append(model)
    model = get_vgg_unet(step_sz, weights=None)
    model.load_weights(path.join(models_folder, 'vgg_clahe_model_weights_2.h5'))
    models_vgg_clahe.append(model)
    model = get_vgg_unet(step_sz, weights=None)
    model.load_weights(path.join(models_folder, 'vgg_clahe_model_weights_3.h5'))
    models_vgg_clahe.append(model)
    
    models_linknet = []
    model = get_linknet(step_sz)
    model.load_weights(path.join(models_folder, 'linknet_model_weights_0.h5'))
    models_linknet.append(model)
    model = get_linknet(step_sz)
    model.load_weights(path.join(models_folder, 'linknet_model_weights_1.h5'))
    models_linknet.append(model)
    model = get_linknet(step_sz)
    model.load_weights(path.join(models_folder, 'linknet_model_weights_2.h5'))
    models_linknet.append(model)
    model = get_linknet(step_sz)
    model.load_weights(path.join(models_folder, 'linknet_model_weights_3.h5'))
    models_linknet.append(model)

                
    all_models =  models_linknet + models + models_vgg
    all_models_clahe = models_resnet_clahe + models_vgg_clahe
    print('predicting test')
    j = 0
    for f in tqdm(listdir(data_folder)):
        if path.isfile(path.join(data_folder, f)) and '_RGB.tif' in f:
            predict_image(data_folder, pred_folder, f, all_models, all_models_clahe)
            j += 1
            
    elapsed = timeit.default_timer() - t0
    print('Time: {:.3f} min'.format(elapsed / 60))