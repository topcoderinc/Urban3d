# -*- coding: utf-8 -*-
import os
import sys

#if len(sys.argv) > 2:
#    os.environ['CUDA_VISIBLE_DEVICES'] = sys.argv[2]

from os import path, listdir, mkdir
import numpy as np
np.random.seed(1)
import random
random.seed(1)
import tensorflow as tf
tf.set_random_seed(1)
import timeit
from sklearn.model_selection import KFold
import cv2
from keras.optimizers import Adam
from keras import metrics
from keras.callbacks import ModelCheckpoint
from models import get_vgg_unet, dice_coef, dice_logloss, dice_coef_rounded

input_shape = (512, 512)

def preprocess_input_keras(x):
    x = np.asarray(x, dtype='float32')
    x[..., 0] -= 103.939
    x[..., 1] -= 116.779
    x[..., 2] -= 123.68
    return x

data_folder = 'training'
masks_fixed_folder = 'masks_fixed'
models_folder = 'nn_models'

all_files = []
all_images = []
all_masks = []
all_dsm = []
all_dtm = []
all_diff = []

def do_clahe(img):
    clahe = cv2.createCLAHE(clipLimit=1.0, tileGridSize=(21, 21))
    cl1 = img.copy()
    cl1[:, :, 0] = clahe.apply(img[:, :, 0])
    cl1[:, :, 1] = clahe.apply(img[:, :, 1])
    cl1[:, :, 2] = clahe.apply(img[:, :, 2])
    return cl1
        
def batch_data_generator(train_idx, batch_size):
    while True:
        inputs = []
        inputs2 = []
        outputs = []
        for i in train_idx:
            for j in range(10):
                x0 = random.randint(0, all_images[i].shape[1] - input_shape[1]) 
                y0 = random.randint(0, all_images[i].shape[0] - input_shape[0])
                img = all_images[i][y0:y0+input_shape[0], x0:x0+input_shape[1], :]
                diff = all_diff[i][y0:y0+input_shape[0], x0:x0+input_shape[1]]
                otp = all_masks[i][y0:y0+input_shape[0], x0:x0+input_shape[1]]

                if random.random() > 0.5:
                    img = img[:, ::-1,...]
                    diff = diff[:, ::-1,...]
                    otp = otp[:, ::-1,...]
                
                if otp.sum() > 1:
                    inputs.append(img)
                    inputs2.append(diff)
                    outputs.append(otp)
            
        inputs = np.asarray(inputs)
        inputs2 = np.asarray(inputs2)
        outputs = np.asarray(outputs)
        inputs = preprocess_input_keras(inputs)
        inputs2 = inputs2[..., np.newaxis]
        outputs = outputs[..., np.newaxis]
        
        idxs = [i for i in range(inputs.shape[0])]
        np.random.shuffle(idxs)
        inputs = inputs[idxs]
        inputs2 = inputs2[idxs]
        outputs = outputs[idxs]
        
        i = 0
        while i + batch_size < inputs.shape[0]:
            yield [inputs[i:i + batch_size], inputs2[i:i + batch_size]], outputs[i:i + batch_size]
            i += batch_size
            
if __name__ == '__main__':
    t0 = timeit.default_timer()
    
#    fold_num = -1
#    if len(sys.argv) > 1:
#        fold_num = int(sys.argv[1])

    if len(sys.argv) > 1:
        data_folder = sys.argv[1]
        
    if not path.isdir(models_folder):
        mkdir(models_folder)
    
    for f in sorted(listdir(data_folder)):
        if path.isfile(path.join(data_folder, f)) and '_RGB.tif' in f:
            if not path.isfile(path.join(masks_fixed_folder, f.replace('.tif', '.png'))):
                continue
            
            print(f)
            all_files.append(f)
            img = cv2.imread(path.join(data_folder, f), cv2.IMREAD_UNCHANGED)
            img = do_clahe(img)
            msk = cv2.imread(path.join(masks_fixed_folder, f.replace('.tif', '.png')), cv2.IMREAD_UNCHANGED)
            msk = (msk > 127) * 1
            dsm = cv2.imread(path.join(data_folder, f.replace('_RGB', '_DSM')), cv2.IMREAD_UNCHANGED)
            dtm = cv2.imread(path.join(data_folder, f.replace('_RGB', '_DTM')), cv2.IMREAD_UNCHANGED)
            diff = dsm - dtm
            all_diff.append(diff)
            msk = np.asarray(msk, dtype=np.uint8)
            all_images.append(img)
            all_masks.append(msk)
    all_images = np.asarray(all_images)
    all_masks = np.asarray(all_masks)
    all_diff = np.asarray(all_diff)

    batch_size = 4
    it = -1
    kf = KFold(n_splits=4, shuffle=True, random_state=1)
    for train_idx, val_idx in kf.split(all_files):
        it += 1
        
#        if fold_num != -1 and it != fold_num:
#            continue
        
        np.random.seed(it+1)
        random.seed(it+1)
        tf.set_random_seed(it+1)
        
        print('it:', it, 'vals:', val_idx)
        
        val_inp = []
        val_inp2 = []
        val_otp = []
        
        for i in val_idx:
            x = 0
            while x + input_shape[1] <= all_images[i].shape[1]:
                y = 0
                while y + input_shape[0] <= all_images[i].shape[0]:
                    val_inp.append(all_images[i][y:y+input_shape[0], x:x+input_shape[1], :])
                    val_inp2.append(all_diff[i][y:y+input_shape[0], x:x+input_shape[1]])
                    val_otp.append(all_masks[i][y:y+input_shape[0], x:x+input_shape[1]])
                    
                    if y + input_shape[0] > all_images[i].shape[0]:
                        y = img.shape[0] - input_shape[0]
                    else:
                        y += input_shape[0]
                if x + input_shape[1] > all_images[i].shape[1]:
                    x = img.shape[1] - input_shape[1]
                else:
                    x += input_shape[1]
            
        val_inp = np.asarray(val_inp)
        val_inp2 = np.asarray(val_inp2)
        val_otp = np.asarray(val_otp)
        val_inp = preprocess_input_keras(val_inp)
        val_inp2 = val_inp2[..., np.newaxis]
        val_otp = val_otp[..., np.newaxis]

        print('Training model', it)
        
        model = get_vgg_unet(input_shape)
            
        model.compile(loss=dice_logloss,
                      optimizer=Adam(lr=2e-4),
                      metrics=[dice_coef, dice_coef_rounded, metrics.binary_crossentropy])
        
        model_checkpoint = ModelCheckpoint(path.join(models_folder, 'vgg_clahe_model_weights_{0}.h5'.format(it)), monitor='val_dice_coef_rounded', 
                                           save_best_only=True, save_weights_only=True, mode='max')
        model.fit_generator(generator=batch_data_generator(train_idx, batch_size),
                              epochs=20, steps_per_epoch=300, verbose=2,
                              validation_data=([val_inp, val_inp2], [val_otp]),
                              callbacks=[model_checkpoint])
        model.optimizer = Adam(lr=5e-5)
        model.fit_generator(generator=batch_data_generator(train_idx, batch_size),
                              epochs=10, steps_per_epoch=300, verbose=2,
                              validation_data=([val_inp, val_inp2], [val_otp]),
                              callbacks=[model_checkpoint])
        
    elapsed = timeit.default_timer() - t0
    print('Time: {:.3f} min'.format(elapsed / 60))