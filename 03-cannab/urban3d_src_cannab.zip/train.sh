python train_resnet.py $1 | tee out_train_resnet.txt 
python train_resnet_clahe.py $1 | tee out_train_resnet_clahe.txt 
python train_vgg.py $1 | tee out_train_vgg.txt 
python train_vgg_clahe.py $1 | tee out_train_vgg_clahe.txt 
python train_linknet.py $1 | tee out_train_linknet.txt 
python predict_train.py $1 
python train_classifier.py $1 | tee out_train_classifier.txt 