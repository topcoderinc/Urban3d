from keras import layers
from keras.models import Model
from keras.layers import Input, BatchNormalization, Conv2D, MaxPooling2D, concatenate, Activation, Conv2DTranspose

bn_axis = 3

def linknet_residual_block(input_tensor, filters, shortcut=None):
    if shortcut is None:
        shortcut = input_tensor
    
    x = Conv2D(filters, (3, 3), padding='same')(input_tensor)
    x = BatchNormalization(axis=bn_axis)(x)
    x = Activation('relu')(x)
    
    x = Conv2D(filters, (3, 3), padding='same')(x)
    x = BatchNormalization(axis=bn_axis)(x)
    
    x = layers.add([x, input_tensor])
    x = Activation('relu')(x)
    return x

def linknet_conv_block(input_tensor, filters, res_blocks, stride=2):
    if stride == 1:
        x = input_tensor
    else:
        x = Conv2D(filters, (3, 3), strides=(stride, stride), padding='same')(input_tensor)
        x = BatchNormalization(axis=bn_axis)(x)
    
    for i in range(res_blocks):
        x = linknet_residual_block(x, filters)
        
    return x

def linknet_deconv_block(input_tensor, filters_in, filters_out):
    x = Conv2D(int(filters_in/4), (1, 1), padding='same')(input_tensor)
    x = BatchNormalization(axis=bn_axis)(x)
    x = Activation('relu')(x)

    x = Conv2DTranspose(int(filters_in/4), (3, 3), strides=(2, 2), padding='same')(x)
    x = BatchNormalization(axis=bn_axis)(x)
    x = Activation('relu')(x)
    
    x = Conv2D(filters_out, (1, 1), padding='same')(x)
    x = BatchNormalization(axis=bn_axis)(x)
    x = Activation('relu')(x)
    return x

def get_linknet(input_shape=(512, 512)):
    input1 = Input(input_shape + (3,))
    input2 = Input(input_shape + (1,))
    
    inp = concatenate([input1, input2], axis=-1)
    
    x = Conv2D(
        64, (7, 7), strides=(2, 2), padding='same')(inp)
    x = BatchNormalization(axis=bn_axis)(x)
    x = Activation('relu')(x)
    x = MaxPooling2D((3, 3), strides=(2, 2), padding='same')(x)
    
    enc1 = linknet_conv_block(x, 64, 2, stride=1)
    enc2 = linknet_conv_block(enc1, 128, 2)
    enc3 = linknet_conv_block(enc2, 256, 2)
    enc4 = linknet_conv_block(enc3, 512, 2)
    
    dec4 = linknet_deconv_block(enc4, 512, 256)
    dec4 = layers.add([dec4, enc3])
    dec3 = linknet_deconv_block(dec4, 256, 128)
    dec3 = layers.add([dec3, enc2])
    dec2 = linknet_deconv_block(dec3, 128, 64)
    dec2 = layers.add([dec2, enc1])
    
    dec1 = linknet_deconv_block(dec2, 64, 64)
    
    x = Conv2DTranspose(64, (3, 3), strides=(2, 2), padding='same')(dec1)
    x = BatchNormalization(axis=bn_axis)(x)
    x = Activation('relu')(x)
    
    x = Conv2D(32, (3, 3), padding='same')(x)
    x = BatchNormalization(axis=bn_axis)(x)
    x = Activation('relu')(x)
    
    x = Conv2D(1, (1, 1), activation='sigmoid')(x)
    
    model = Model([input1, input2], x)
    
    return model