from keras.applications.vgg16 import VGG16
from keras import backend as K
from keras.models import Model
from keras.layers import Input, BatchNormalization, Conv2D, MaxPooling2D, concatenate, UpSampling2D, Activation, SpatialDropout2D
from resnet50_padding_same import ResNet50
from keras.losses import binary_crossentropy

def dice_coef(y_true, y_pred):
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    intersection = K.sum(y_true_f * y_pred_f)
    return (2. * intersection + 1) / (K.sum(y_true_f) + K.sum(y_pred_f) + 1)

def dice_coef_rounded(y_true, y_pred):
    y_true_f = K.flatten(K.round(y_true))
    y_pred_f = K.flatten(K.round(y_pred))
    intersection = K.sum(y_true_f * y_pred_f)
    return (2. * intersection + 1) / (K.sum(y_true_f) + K.sum(y_pred_f) + 1)

def dice_coef_loss(y_true, y_pred):
    return 1 - (dice_coef(y_true, y_pred))

def dice_logloss(y_true, y_pred):
    return binary_crossentropy(y_true, y_pred) * 0.5 + dice_coef_loss(y_true, y_pred) * 0.5


#from https://www.kaggle.com/lyakaap/weighing-boundary-pixels-loss-script-by-keras2
# weight: weighted tensor(same shape with mask image)
def weighted_bce_loss(y_true, y_pred, weight):
    # avoiding overflow
    epsilon = 1e-7
    y_pred = K.clip(y_pred, epsilon, 1. - epsilon)
    logit_y_pred = K.log(y_pred / (1. - y_pred))
    
    # https://www.tensorflow.org/api_docs/python/tf/nn/weighted_cross_entropy_with_logits
    loss = (1. - y_true) * logit_y_pred + (1. + (weight - 1.) * y_true) * \
    (K.log(1. + K.exp(-K.abs(logit_y_pred))) + K.maximum(-logit_y_pred, 0.))
    return K.sum(loss) / K.sum(weight)

def weighted_dice_loss(y_true, y_pred, weight):
    smooth = 1.
    w, m1, m2 = weight * weight, y_true, y_pred
    intersection = (m1 * m2)
    score = (2. * K.sum(w * intersection) + smooth) / (K.sum(w * m1) + K.sum(w * m2) + smooth)
    loss = 1. - K.sum(score)
    return loss

def weighted_bce_dice_loss(y_true, y_pred):
    y_true = K.cast(y_true, 'float32')
    y_pred = K.cast(y_pred, 'float32')
    # if we want to get same size of output, kernel size must be odd number
    averaged_mask = K.pool2d(
            y_true, pool_size=(11, 11), strides=(1, 1), padding='same', pool_mode='avg')
    border = K.cast(K.greater(averaged_mask, 0.005), 'float32') * K.cast(K.less(averaged_mask, 0.995), 'float32')
    weight = K.ones_like(averaged_mask)
    w0 = K.sum(weight)
    weight += border * 2
    w1 = K.sum(weight)
    weight *= (w0 / w1)
    loss = weighted_bce_loss(y_true, y_pred, weight) + \
    weighted_dice_loss(y_true, y_pred, weight)
    return loss

def conv_block(prev, num_filters, kernel=(3, 3), strides=(1, 1), act='relu', prefix=None):
    name = None
    if prefix is not None:
        name = prefix + '_conv'
    conv = Conv2D(num_filters, kernel, padding='same', kernel_initializer='he_normal', strides=strides, name=name)(prev)
    if prefix is not None:
        name = prefix + '_norm'
    conv = BatchNormalization(name=name)(conv)
    if prefix is not None:
        name = prefix + '_act'
    conv = Activation(act, name=name)(conv)
    return conv

def get_resnet_unet(input_shape, weights='imagenet'):
    resnet50 = ResNet50(input_shape=input_shape + (3,), weights=weights, include_top=False)
    
    conv_idxs = []
    for i in range(len(resnet50.layers) - 1):
        resnet50.layers[i].trainable = False
        if isinstance(resnet50.layers[i], Activation) and resnet50.layers[i].output_shape[1:3] != resnet50.layers[i+1].output_shape[1:3]:
            conv_idxs.append(i)
    
    resnet_conv1 = resnet50.layers[conv_idxs[0]].output
    resnet_conv2 = resnet50.layers[conv_idxs[1]].output
    resnet_conv3 = resnet50.layers[conv_idxs[2]].output
    resnet_conv4 = resnet50.layers[conv_idxs[3]].output
    resnet_conv5 = resnet50.layers[conv_idxs[4]].output

    input2 = Input(input_shape + (1,))
    
    conv0 = conv_block(input2, 8)
    conv0 = conv_block(conv0, 8)
    pool0 = MaxPooling2D(pool_size=(2, 2), padding='same')(conv0)
    
    conv1 = conv_block(pool0, 12)
    conv1 = conv_block(conv1, 12)
    pool1 = MaxPooling2D(pool_size=(2, 2), padding='same')(conv1)

    conv2 = conv_block(pool1, 16)
    conv2 = conv_block(conv2, 16)
    pool2 = MaxPooling2D(pool_size=(2, 2), padding='same')(conv2)

    conv3 = conv_block(pool2, 32)
    conv3 = conv_block(conv3, 32)
    pool3 = MaxPooling2D(pool_size=(2, 2), padding='same')(conv3)

    conv4 = conv_block(pool3, 48)
    conv4 = conv_block(conv4, 48)
    pool4 = MaxPooling2D(pool_size=(2, 2), padding='same')(conv4)
    
    conv5 = conv_block(pool4, 64)
    conv5 = conv_block(conv5, 64)

    up6 = concatenate([UpSampling2D()(resnet_conv5), resnet_conv4, UpSampling2D()(conv5), conv4], axis=-1)
    conv6 = conv_block(up6, 192)
    conv6 = conv_block(conv6, 192)

    up7 = concatenate([UpSampling2D()(conv6), resnet_conv3, conv3], axis=-1)
    conv7 = conv_block(up7, 128)
    conv7 = conv_block(conv7, 128)

    up8 = concatenate([UpSampling2D()(conv7), resnet_conv2, conv2], axis=-1)
    conv8 = conv_block(up8, 96)
    conv8 = conv_block(conv8, 96)

    up9 = concatenate([UpSampling2D()(conv8), resnet_conv1, conv1], axis=-1)
    conv9 = conv_block(up9, 64)
    conv9 = conv_block(conv9, 64)

    up10 = concatenate([UpSampling2D()(conv9), resnet50.input, conv0, input2], axis=-1)
    conv10 = conv_block(up10, 32)
    conv10 = conv_block(conv10, 32)
    conv10 = SpatialDropout2D(0.33)(conv10)
    res = Conv2D(1, (1, 1), activation='sigmoid')(conv10)
    model = Model([resnet50.input, input2], res)
    return model


def get_vgg_unet(input_shape, weights='imagenet'):  
    input1 = Input(input_shape + (3,))
    input2 = Input(input_shape + (1,))
    
    inp = concatenate([input1, input2], axis=-1)
    
    conv1 = conv_block(inp, 64, prefix='conv1')
    conv1 = conv_block(conv1, 64, prefix='conv1_2')
    pool1 = MaxPooling2D(pool_size=(2, 2), padding='same')(conv1)

    conv2 = conv_block(pool1, 128, prefix='conv2')
    conv2 = conv_block(conv2, 128, prefix='conv2_2')
    pool2 = MaxPooling2D(pool_size=(2, 2), padding='same')(conv2)

    conv3 = conv_block(pool2, 256, prefix='conv3')
    conv3 = conv_block(conv3, 256, prefix='conv3_2')
    conv3 = conv_block(conv3, 256, prefix='conv3_3')
    pool3 = MaxPooling2D(pool_size=(2, 2), padding='same')(conv3)

    conv4 = conv_block(pool3, 512, prefix='conv4')
    conv4 = conv_block(conv4, 512, prefix='conv4_2')
    conv4 = conv_block(conv4, 512, prefix='conv4_3')
    pool4 = MaxPooling2D(pool_size=(2, 2), padding='same')(conv4)
    
    conv5 = conv_block(pool4, 512, prefix='conv5')
    conv5 = conv_block(conv5, 512, prefix='conv5_2')
    conv5 = conv_block(conv5, 512, prefix='conv5_3')

    up6 = concatenate([UpSampling2D()(conv5), conv4], axis=-1)
    conv6 = conv_block(up6, 128)
    conv6 = conv_block(conv6, 128)

    up7 = concatenate([UpSampling2D()(conv6), conv3], axis=-1)
    conv7 = conv_block(up7, 64)
    conv7 = conv_block(conv7, 64)

    up8 = concatenate([UpSampling2D()(conv7), conv2], axis=-1)
    conv8 = conv_block(up8, 64)
    conv8 = conv_block(conv8, 64)

    up9 = concatenate([UpSampling2D()(conv8), conv1], axis=-1)
    conv9 = conv_block(up9, 32)
    conv9 = conv_block(conv9, 32)
#    conv9 = SpatialDropout2D(0.33)(conv9)
    res = Conv2D(1, (1, 1), activation='sigmoid')(conv9)
    model = Model([input1, input2], res)
    
    if weights == 'imagenet':
        vgg16 = VGG16(input_shape=input_shape + (3,), weights=weights, include_top=False)
        vgg_l = vgg16.get_layer('block1_conv1')
        l = model.get_layer('conv1_conv')
        w0 = vgg_l.get_weights()
        w = l.get_weights()
        w[0][:, :, 0:3, :] = w0[0]
        w[1] = w0[1]
        l.set_weights(w)
        vgg_l = vgg16.get_layer('block1_conv2')
        l = model.get_layer('conv1_2_conv')
        l.set_weights(vgg_l.get_weights())
        
        vgg_l = vgg16.get_layer('block2_conv1')
        l = model.get_layer('conv2_conv')
        l.set_weights(vgg_l.get_weights())
        vgg_l = vgg16.get_layer('block2_conv2')
        l = model.get_layer('conv2_2_conv')
        l.set_weights(vgg_l.get_weights())
        
        vgg_l = vgg16.get_layer('block3_conv1')
        l = model.get_layer('conv3_conv')
        l.set_weights(vgg_l.get_weights())
        vgg_l = vgg16.get_layer('block3_conv2')
        l = model.get_layer('conv3_2_conv')
        l.set_weights(vgg_l.get_weights())
        vgg_l = vgg16.get_layer('block3_conv3')
        l = model.get_layer('conv3_3_conv')
        l.set_weights(vgg_l.get_weights())
        
        vgg_l = vgg16.get_layer('block4_conv1')
        l = model.get_layer('conv4_conv')
        l.set_weights(vgg_l.get_weights())
        vgg_l = vgg16.get_layer('block4_conv2')
        l = model.get_layer('conv4_2_conv')
        l.set_weights(vgg_l.get_weights())
        vgg_l = vgg16.get_layer('block4_conv3')
        l = model.get_layer('conv4_3_conv')
        l.set_weights(vgg_l.get_weights())
        
        vgg_l = vgg16.get_layer('block5_conv1')
        l = model.get_layer('conv5_conv')
        l.set_weights(vgg_l.get_weights())
        vgg_l = vgg16.get_layer('block5_conv2')
        l = model.get_layer('conv5_2_conv')
        l.set_weights(vgg_l.get_weights())
        vgg_l = vgg16.get_layer('block5_conv3')
        l = model.get_layer('conv5_3_conv')
        l.set_weights(vgg_l.get_weights())
        
    return model