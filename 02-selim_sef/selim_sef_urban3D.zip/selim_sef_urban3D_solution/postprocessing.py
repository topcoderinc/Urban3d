import numpy as np
from cv2 import imwrite
from scipy import ndimage
from skimage.morphology import watershed


def label_watershed(image, threshold_before, threshold_after, component_size):
    mask_img_before = np.copy(image)
    mask_img_after = np.copy(image)

    mask_img_before[image < threshold_before] = 0
    mask_img_before[image >= threshold_before] = 1
    mask_img_after[image < threshold_after] = 0
    mask_img_after[image >= threshold_after] = 1
    markers = ndimage.label(mask_img_before)[0]
    labels = watershed(mask_img_after, markers, mask=mask_img_after)
    unique, counts = np.unique(labels, return_counts=True)
    for (k, v) in dict(zip(unique, counts)).items():
        if v < component_size:
            labels[labels == k] = 0
    imwrite("watershed.png", (labels > 0) * 255)
    return labels