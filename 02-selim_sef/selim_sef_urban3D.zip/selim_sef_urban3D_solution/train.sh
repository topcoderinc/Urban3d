#!/usr/bin/env bash

python3 train.py \
 --gpu="0" \
 --models_dir=/work/trained_models \
 --img_dir=$1 \
 --mask_dir=/work/fixed_masks \
 --network=unet_vgg \
 --loss_function=bce_dice \
 --alias=DECODER \
 --freeze_till_layer=block5_pool \
 --preprocessing_function=caffe \
 --learning_rate=0.001 \
 --crop_size=256 \
 --save_epochs="0" \
 --crops_per_image=4 \
 --batch_size=3 \
 --epochs=1 \
 --steps_per_epoch=2000

python3 train.py \
 --gpu="0" \
 --models_dir=/work/trained_models \
 --img_dir=$1 \
 --mask_dir=/work/fixed_masks \
 --network=unet_vgg \
 --loss_function=triple_border_bce_dice \
 --clr="0.00008,0.001,4000,triangular2" \
 --preprocessing_function=caffe \
 --learning_rate=0.001 \
 --crop_size=256 \
 --save_epochs="22,23,24,29,30,31,32" \
 --crops_per_image=4 \
 --batch_size=4 \
 --epochs=33 \
 --weights=/work/trained_models/DECODERunet_vgg_bce_dice_1.h5 \
 --steps_per_epoch=1000

python3 train.py \
 --gpu="0" \
 --models_dir=/work/trained_models \
 --img_dir=$1 \
 --mask_dir=/work/fixed_masks \
 --network=unet_vgg \
 --loss_function=bce_dice \
 --clr="0.00008,0.001,4000,triangular2" \
 --preprocessing_function=caffe \
 --learning_rate=0.001 \
 --crop_size=256 \
 --save_epochs="22,23,24,29,30,31,32" \
 --crops_per_image=4 \
 --batch_size=4 \
 --epochs=33 \
 --weights=/work/trained_models/DECODERunet_vgg_bce_dice_1.h5 \
 --steps_per_epoch=1000

python3 train.py \
 --gpu="0" \
 --models_dir=/work/trained_models \
 --img_dir=$1 \
 --mask_dir=/work/fixed_masks \
 --network=linknet \
 --loss_function=bce_dice \
 --clr="0.0001,0.001,4000,triangular2" \
 --preprocessing_function=tf \
 --learning_rate=0.001 \
 --crop_size=256 \
 --save_epochs="29,30,31,32" \
 --crops_per_image=4 \
 --batch_size=4 \
 --epochs=33 \
 --steps_per_epoch=1000

python3 train.py \
 --gpu="0" \
 --models_dir=/work/trained_models \
 --img_dir=$1 \
 --mask_dir=/work/fixed_masks \
 --network=linknet_subpixel \
 --loss_function=bce_dice \
 --clr="0.0001,0.001,4000,triangular2" \
 --preprocessing_function=tf \
 --learning_rate=0.001 \
 --crop_size=256 \
 --save_epochs="29,30,31,32" \
 --crops_per_image=4 \
 --batch_size=4 \
 --epochs=33 \
 --steps_per_epoch=1000

python3 train.py \
 --gpu="0" \
 --models_dir=/work/trained_models \
 --img_dir=$1 \
 --mask_dir=/work/fixed_masks \
 --network=linknet_conv1 \
 --loss_function=bce_dice \
 --clr="0.0001,0.001,4000,triangular2" \
 --preprocessing_function=tf \
 --learning_rate=0.001 \
 --crop_size=256 \
 --save_epochs="29,30,31,32" \
 --crops_per_image=4 \
 --batch_size=4 \
 --epochs=33 \
 --steps_per_epoch=1000

python3 train.py \
 --gpu="0" \
 --models_dir=/work/trained_models \
 --img_dir=$1 \
 --mask_dir=/work/fixed_masks \
 --network=linknet_subpixel_conv1 \
 --loss_function=bce_dice \
 --clr="0.0001,0.001,4000,triangular2" \
 --preprocessing_function=tf \
 --learning_rate=0.001 \
 --crop_size=256 \
 --save_epochs="29,30,31,32" \
 --crops_per_image=4 \
 --batch_size=4 \
 --epochs=33 \
 --steps_per_epoch=1000

