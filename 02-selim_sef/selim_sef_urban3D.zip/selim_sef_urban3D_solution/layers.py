import keras.backend as K
from keras.layers.core import Lambda


def SubpixelConv2D(scale=4, name='subpixel'):
    """
    Keras layer to do subpixel convolution.
    NOTE: Tensorflow backend only. Uses tf.depth_to_space
    Ref:
        [1] Real-Time Single Image and Video Super-Resolution Using an Efficient Sub-Pixel Convolutional Neural Network
            Shi et Al.
            https://arxiv.org/abs/1609.05158
    :param input_shape: tensor shape, (batch, height, width, channel)
    :param scale: upsampling scale. Default=4
    :return:
    """
    # upsample using depth_to_space
    def subpixel_shape(input_shape):
        dims = [input_shape[0],
                input_shape[1] * scale,
                input_shape[2] * scale,
                int(input_shape[3] / (scale ** 2))] if input_shape[0] is not None else [None, None, None, int(input_shape[3] / (scale ** 2))]

        output_shape = tuple(dims)
        return output_shape

    def subpixel(x):
        return K.tf.depth_to_space(x, scale)


    return Lambda(subpixel, output_shape=subpixel_shape, name=name)