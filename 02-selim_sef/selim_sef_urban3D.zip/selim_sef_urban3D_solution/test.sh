#!/usr/bin/env bash

python3 predict_all.py --gpu "0" --test_dir $2 --out_path $3