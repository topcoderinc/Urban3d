import cv2
from skimage import measure

import numpy as np
import subprocess
from scipy import ndimage
import re
import os

from params import args
from tools.rle import rle_to_string, rlencode


def calculate_visualizer(y_true, y_pred, tile_ids, fold=0, threshold=0.5, pixel_threshold=100):
    truth_csv = os.path.join(args.models_dir, "y_true_{}.csv".format(fold))
    pred_csv = os.path.join(args.models_dir, "y_pred_{}.csv".format(fold))
    generate_files(pixel_threshold, pred_csv, threshold, tile_ids, truth_csv, y_pred, y_true)
    truth_file = truth_csv
    poly_file = pred_csv

    cmd = [
        'java',
        '-jar',
        args.visualizer_path,
        '-truth',
        truth_file,
        '-solution',
        poly_file,
        '-no-gui',
        '-data-dir',
        args.img_dir
    ]
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    stdout_data, stderr_data = proc.communicate()
    lines = [line for line in stdout_data.decode('utf8').strip().split('\n')[-10:]]
    overall_fscore = float(re.findall("([\d\.]+)", lines[-1])[0])

    return overall_fscore


def generate_files(pixel_threshold, pred_csv, threshold, tile_ids, truth_csv, y_pred, y_true):
    gt_submit = open(truth_csv, "w")
    f_submit = open(pred_csv, "w")
    for i in range(len(y_true)):

        tile_id = tile_ids[i]
        mask_img = y_pred[i]
        gt_mask_img = y_true[i]
        mask_img[mask_img <= threshold] = 0
        mask_img[mask_img > threshold] = 1

        labeled_array, num_features = ndimage.label(mask_img)
        unique, counts = np.unique(labeled_array, return_counts=True)
        for (k, v) in dict(zip(unique, counts)).items():
            if v < pixel_threshold:
                mask_img[labeled_array == k] = 0
        labeled_array, num_features = ndimage.label(mask_img)

        rle_str = rle_to_string(rlencode(labeled_array.flatten()))
        f_submit.write("{tile_id}\n2048,2048\n{rle}\n".format(tile_id=tile_id, rle=rle_str))

        labeled_array, num_features = ndimage.label(gt_mask_img)
        rle_str = rle_to_string(rlencode(labeled_array.flatten()))
        gt_submit.write("{tile_id}\n2048,2048\n{rle}\n".format(tile_id=tile_id, rle=rle_str))
    f_submit.close()
    gt_submit.close()


def get_buildings(mask, pixel_threshold):
    gt_labeled_array, gt_num = ndimage.label(mask)
    unique, counts = np.unique(gt_labeled_array, return_counts=True)
    for (k, v) in dict(zip(unique, counts)).items():
        if v < pixel_threshold:
            mask[gt_labeled_array == k] = 0
    return measure.label(mask, return_num=True)


def calculate_f1_buildings_score(y_true, y_pred, iou_threshold=0.45, probability_threshold=0.5, component_size_threshold=100):
    tp = 0
    fp = 0
    fn = 0
    for m in range(len(y_true)):
        processed_gt = set()
        matched = set()
        size = y_pred[m].shape[0], y_pred[m].shape[1]
        mask_img = np.reshape(y_pred[m], size)
        gt_mask_img = np.reshape(y_true[m], size)

        mask_img[mask_img <= probability_threshold] = 0
        mask_img[mask_img > probability_threshold] = 1
        predicted_labels, predicted_count = get_buildings(mask_img, component_size_threshold)
        gt_labels, gt_count = get_buildings(gt_mask_img, component_size_threshold)

        gt_buildings = [rp.coords for rp in measure.regionprops(gt_labels)]
        pred_buildings = [rp.coords for rp in measure.regionprops(predicted_labels)]
        gt_buildings = [to_point_set(b) for b in gt_buildings]
        pred_buildings = [to_point_set(b) for b in pred_buildings]
        for j in range(predicted_count):
            match_found = False
            for i in range(gt_count):
                pred_ind = j + 1
                gt_ind = i + 1
                if match_found:
                    break
                if gt_ind in processed_gt:
                    continue
                pred_building = pred_buildings[j]
                gt_building = gt_buildings[i]
                intersection = len(pred_building.intersection(gt_building))
                union = len(pred_building) + len(gt_building) - intersection
                iou = intersection / union
                if iou > iou_threshold:
                    processed_gt.add(gt_ind)
                    matched.add(pred_ind)
                    match_found = True
                    tp += 1
            if not match_found:
                fp += 1
        fn += gt_count - len(processed_gt)
    precision = tp / (tp + fp)
    recall = tp / (tp + fn)
    if precision == 0 or recall == 0:
        return 0
    f_score = 2 * precision * recall / (precision + recall)
    return f_score


def to_point_set(building):
    return set([(row[0], row[1]) for row in building])
