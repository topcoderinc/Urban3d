import random
from abc import abstractmethod

import cv2
import os
import numpy as np
import time

from keras.applications import imagenet_utils
from keras.preprocessing.image import Iterator, load_img, img_to_array

from params import args


class BaseMaskDatasetIterator(Iterator):
    def __init__(self,
                 data_dir,
                 mask_dir,
                 image_ids,
                 crop_shape,
                 random_transformer=None,
                 batch_size=8,
                 crops_per_image=3,
                 shuffle=True,
                 image_name_template=None,
                 mask_template=None,
                 resize=None,
                 seed=None):
        self.data_dir = data_dir
        self.mask_dir = mask_dir
        self.image_ids = image_ids
        self.image_name_template = image_name_template
        self.mask_template = mask_template
        self.random_transformer = random_transformer
        self.crop_shape = crop_shape
        self.resize = resize
        self.crops_per_image = crops_per_image

        if seed is None:
            seed = np.uint32(time.time() * 1000)

        super(BaseMaskDatasetIterator, self).__init__(len(self.image_ids), batch_size, shuffle, seed)

    @abstractmethod
    def transform_mask(self, mask, image):
        raise NotImplementedError

    def transform_batch_y(self, batch_y):
        return batch_y

    def _get_batches_of_transformed_samples(self, index_array):
        batch_x = []
        batch_y = []

        for batch_index, image_index in enumerate(index_array):
            id = self.image_ids[image_index]
            img_name = self.image_name_template.format(id=id)
            path = os.path.join(self.data_dir, img_name)
            image = img_to_array(load_img(path))
            mask_name = self.mask_template.format(id=id)
            mask_path = os.path.join(self.mask_dir, mask_name)
            mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
            if self.resize:
                mask = cv2.resize(mask, (self.resize[1], self.resize[0]), cv2.INTER_AREA)
                image = cv2.resize(image, (self.resize[1], self.resize[0]), cv2.INTER_AREA)
            ori_height = image.shape[0]
            ori_width = image.shape[1]

            mask = self.transform_mask(mask, image)
            if self.random_transformer is not None:
                image, mask = self.random_transformer.random_transform(image, mask)
            if self.crop_shape is not None:
                for c in range(self.crops_per_image):
                    if self.random_transformer is None:
                        y_start = (ori_height - self.crop_shape[0]) // 2
                        x_start = (ori_width - self.crop_shape[1]) // 2
                    else:
                        y_start = random.randint(0, ori_height - self.crop_shape[0] - 1)
                        x_start = random.randint(0, ori_width - self.crop_shape[1] - 1)
                    y_end = y_start + self.crop_shape[0]
                    x_end = x_start + self.crop_shape[1]
                    crop_image = image[y_start:y_end, x_start:x_end, :]
                    crop_mask = mask[y_start:y_end, x_start:x_end, :]
                    batch_x.append(crop_image)
                    batch_y.append(crop_mask)
            else:
                batch_x.append(image)
                batch_y.append(mask)
        batch_x = np.array(batch_x, dtype="float32")
        batch_y = np.array(batch_y, dtype="float32")
        batch_x = imagenet_utils.preprocess_input(batch_x, mode=args.preprocessing_function)
        return self.transform_batch_x(batch_x), self.transform_batch_y(batch_y)

    def transform_batch_x(self, batch_x):
        return batch_x



