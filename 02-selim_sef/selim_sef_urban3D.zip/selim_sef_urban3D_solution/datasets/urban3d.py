import os
import random

import cv2
import numpy as np
from PIL import Image
from keras.applications import imagenet_utils
from keras.preprocessing.image import img_to_array, load_img

from datasets.base import BaseMaskDatasetIterator
from params import args


def generate_ids(img_dir):
    ids = []
    for f in os.listdir(img_dir):
        if f.endswith("RGB.tif"):
            ids.append(f.split("_RGB.tif")[0])
    return sorted(ids)


class Urban3DIterator(BaseMaskDatasetIterator):
    def __init__(self,
                 data_dir,
                 image_ids,
                 crop_shape,
                 random_transformer=None,
                 batch_size=8,
                 crops_per_image=3,
                 shuffle=True,
                 image_name_template='{id}_RGB.tif',
                 mask_template='{id}_GTL.tif',
                 seed=None):
        super(Urban3DIterator, self).__init__(data_dir, image_ids, crop_shape,
                                              random_transformer, batch_size, crops_per_image, shuffle,
                                              image_name_template, mask_template, None, seed)

    def transform_mask(self, mask, image):
        out_mask = np.zeros((mask.shape[0], mask.shape[1], 1), dtype="float32")
        out_mask[:, :, 0][mask == 6] = 1
        return out_mask


class Urban3DIteratorWithDSM(BaseMaskDatasetIterator):
    def __init__(self,
                 data_dir,
                 mask_dir,
                 image_ids,
                 crop_shape,
                 random_transformer=None,
                 resize=None,
                 batch_size=8,
                 crops_per_image=3,
                 shuffle=True,
                 image_name_template='{id}_RGB.tif',
                 mask_template='{id}_GTL.tif',
                 seed=None):
        super(Urban3DIteratorWithDSM, self).__init__(data_dir, mask_dir, image_ids, crop_shape,
                                                     random_transformer, batch_size, crops_per_image, shuffle,
                                                     image_name_template, mask_template, resize, seed)

    def _get_batches_of_transformed_samples(self, index_array):
        batch_x = []
        batch_x_dsm = []
        batch_y = []

        for batch_index, image_index in enumerate(index_array):
            id = self.image_ids[image_index]
            img_name = self.image_name_template.format(id=id)
            path = os.path.join(self.data_dir, img_name)
            image = img_to_array(load_img(path))
            mask_name = self.mask_template.format(id=id)
            mask_path = os.path.join(self.mask_dir, mask_name)
            dsm_mask_path = os.path.join(self.data_dir, '{id}_DSM.tif'.format(id=id))
            dtm_mask_path = os.path.join(self.data_dir, '{id}_DTM.tif'.format(id=id))
            mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
            dsm_mask = np.array(Image.open(dsm_mask_path))
            dtm_mask = np.array(Image.open(dtm_mask_path))
            dsm_mask = dsm_mask - dtm_mask
            dsm_mask = dsm_mask - 4.32
            if self.resize:
                mask = cv2.resize(mask, (self.resize[1], self.resize[0]), cv2.INTER_NEAREST)
                image = cv2.resize(image, (self.resize[1], self.resize[0]), cv2.INTER_LINEAR)
                dsm_mask = cv2.resize(dsm_mask, (self.resize[1], self.resize[0]), cv2.INTER_NEAREST)
            ori_height = image.shape[0]
            ori_width = image.shape[1]
            mask = self.transform_mask(mask, image)
            dsm = np.zeros((ori_height, ori_width, 1), dtype="float32")
            dsm[:, :, 0] = dsm_mask
            dsm_mask = dsm

            if self.crop_shape is not None:
                for c in range(self.crops_per_image):
                    if self.random_transformer is None:
                        y_start = (ori_height - self.crop_shape[0]) // 2
                        x_start = (ori_width - self.crop_shape[1]) // 2
                    else:
                        y_start = random.randint(0, ori_height - self.crop_shape[0] - 1)
                        x_start = random.randint(0, ori_width - self.crop_shape[1] - 1)
                    y_end = y_start + self.crop_shape[0]
                    x_end = x_start + self.crop_shape[1]
                    crop_image = image[y_start:y_end, x_start:x_end, :]
                    crop_mask = mask[y_start:y_end, x_start:x_end, :]
                    crop_dsm = dsm_mask[y_start:y_end, x_start:x_end, :]
                    if self.random_transformer is not None:
                        crop_double_mask = np.concatenate([crop_mask, crop_dsm], axis=-1)
                        crop_image, crop_double_mask = self.random_transformer.random_transform(crop_image, crop_double_mask)
                        crop_mask = crop_double_mask[:, :, 0:1]
                        crop_dsm = crop_double_mask[:, :, 1:]
                    batch_x.append(crop_image)
                    batch_x_dsm.append(crop_dsm)
                    batch_y.append(crop_mask)
            else:
                batch_x.append(image)
                batch_x_dsm.append(dsm_mask)
                batch_y.append(mask)
        if len(batch_x) == 0:
            return self._get_batches_of_transformed_samples(index_array)
        batch_x = np.array(batch_x, dtype="float32")
        # normalize to zero
        batch_x_dsm = np.array(batch_x_dsm, dtype="float32")
        if args.preprocessing_function == 'tf':
            # scale it between -1 and 1
            max_height = 50
            batch_x_dsm = np.clip(batch_x_dsm, -max_height, max_height)
            batch_x_dsm /= max_height

        batch_y = np.array(batch_y, dtype="float32")

        batch_x = imagenet_utils.preprocess_input(batch_x, mode=args.preprocessing_function)
        batch_x_concat = np.zeros((batch_x.shape[0], batch_x.shape[1], batch_x.shape[2], 4), dtype="float32")
        batch_x_concat[:, :, :, :3] = batch_x
        batch_x_concat[:, :, :, 3:] = batch_x_dsm
        batch_x = batch_x_concat
        return batch_x, self.transform_batch_y(batch_y)

    def transform_mask(self, mask, image):
        out_mask = np.zeros((mask.shape[0], mask.shape[1], 1), dtype="float32")
        out_mask[:, :, 0][mask == 6] = 1
        out_mask[:, :, 0][mask == 65] = 1
        out_mask[np.where(np.all(image == (0, 0, 0), axis=-1))] = 0
        return out_mask


class Urban3DIteratorWithDSMCorrected(Urban3DIteratorWithDSM):
    def __init__(self, data_dir, mask_dir,
                 image_ids, crop_shape,
                 random_transformer=None,
                 resize=None, batch_size=8, crops_per_image=3,
                 shuffle=True, image_name_template='{id}_RGB.tif',
                 mask_template='{id}_GT.png', seed=None):
        super().__init__(data_dir, mask_dir, image_ids, crop_shape, random_transformer, resize, batch_size, crops_per_image, shuffle, image_name_template, mask_template, seed)

    def transform_mask(self, mask, image):
        out_mask = np.zeros((mask.shape[0], mask.shape[1], 1), dtype="float32")
        out_mask[:, :, 0][mask == 255] = 1
        return out_mask