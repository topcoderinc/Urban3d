import numpy as np
from keras.applications.vgg16 import VGG16, WEIGHTS_PATH_NO_TOP
from keras.engine.topology import Input
from keras.engine.training import Model
from keras.layers.convolutional import Conv2D, UpSampling2D
from keras.layers.core import Activation, SpatialDropout2D
from keras.layers.merge import concatenate
from keras.layers.normalization import BatchNormalization
from keras.layers.pooling import MaxPooling2D
from keras.utils.data_utils import get_file

from linknet import LinkNet
from params import args


def conv_block_simple(prevlayer, filters, prefix, strides=(1, 1)):
    conv = Conv2D(filters, (3, 3), padding="same", kernel_initializer="he_normal", strides=strides, name=prefix + "_conv")(prevlayer)
    conv = BatchNormalization(name=prefix + "_bn")(conv)
    conv = Activation('relu', name=prefix + "_activation")(conv)
    return conv


def conv_block_simple_no_bn(prevlayer, filters, prefix, strides=(1, 1)):
    conv = Conv2D(filters, (3, 3), padding="same", kernel_initializer="he_normal", strides=strides, name=prefix + "_conv")(prevlayer)
    conv = Activation('relu', name=prefix + "_activation")(conv)
    return conv

def unet_vgg(input_shape):
    """
        UNet like encoder-decoder model based on VGG encoder
        Supports training on multiple channels, also added batch normalisation.
        Inspired by Deep Image Matting paper https://arxiv.org/abs/1703.03872
    """
    img_input = Input(input_shape)
    # Block 1
    x = Conv2D(64, (3, 3), padding='same', name='block1_conv1')(img_input)
    if input_shape[-1] > 3:
        x = Conv2D(64, (3, 3), padding='same', name='block1_conv1_changed')(img_input)
    x = BatchNormalization(name="block1_conv1_bn")(x)
    x = Activation('relu', name="block1_conv1_activation")(x)
    x = Conv2D(64, (3, 3), padding='same', name='block1_conv2')(x)
    x = BatchNormalization(name="block1_conv2_bn")(x)
    x = Activation('relu', name="block1_conv2_activation")(x)
    conv1 = x
    x = MaxPooling2D((2, 2), strides=(2, 2), name='block1_pool')(x)

    # Block 2
    x = Conv2D(128, (3, 3), padding='same', name='block2_conv1')(x)
    x = BatchNormalization(name="block2_conv1_bn")(x)
    x = Activation('relu', name="block2_conv1_activation")(x)
    x = Conv2D(128, (3, 3), padding='same', name='block2_conv2')(x)
    x = BatchNormalization(name="block2_conv2_bn")(x)
    x = Activation('relu', name="block2_conv2_activation")(x)
    conv2 = x
    x = MaxPooling2D((2, 2), strides=(2, 2), name='block2_pool')(x)

    # Block 3
    x = Conv2D(256, (3, 3), padding='same', name='block3_conv1')(x)
    x = BatchNormalization(name="block3_conv1_bn")(x)
    x = Activation('relu', name="block3_conv1_activation")(x)
    x = Conv2D(256, (3, 3), padding='same', name='block3_conv2')(x)
    x = BatchNormalization(name="block3_conv2_bn")(x)
    x = Activation('relu', name="block3_conv2_activation")(x)
    x = Conv2D(256, (3, 3), padding='same', name='block3_conv3')(x)
    x = BatchNormalization(name="block3_conv3_bn")(x)
    x = Activation('relu', name="block3_conv3_activation")(x)
    conv3 = x
    x = MaxPooling2D((2, 2), strides=(2, 2), name='block3_pool')(x)

    # Block 4
    x = Conv2D(512, (3, 3), padding='same', name='block4_conv1')(x)
    x = BatchNormalization(name="block4_conv1_bn")(x)
    x = Activation('relu', name="block4_conv1_activation")(x)
    x = Conv2D(512, (3, 3), padding='same', name='block4_conv2')(x)
    x = BatchNormalization(name="block4_conv2_bn")(x)
    x = Activation('relu', name="block4_conv2_activation")(x)
    x = Conv2D(512, (3, 3), padding='same', name='block4_conv3')(x)
    x = BatchNormalization(name="block4_conv3_bn")(x)
    x = Activation('relu', name="block4_conv3_activation")(x)
    conv4 = x
    x = MaxPooling2D((2, 2), strides=(2, 2), name='block4_pool')(x)

    # Block 5
    x = Conv2D(512, (3, 3), padding='same', name='block5_conv1')(x)
    x = BatchNormalization(name="block5_conv1_bn")(x)
    x = Activation('relu', name="block5_conv1_activation")(x)
    x = Conv2D(512, (3, 3), padding='same', name='block5_conv2')(x)
    x = BatchNormalization(name="block5_conv2_bn")(x)
    x = Activation('relu', name="block5_conv2_activation")(x)
    x = Conv2D(512, (3, 3), padding='same', name='block5_conv3')(x)
    x = BatchNormalization(name="block5_conv3_bn")(x)
    x = Activation('relu', name="block5_conv3_activation")(x)
    conv5 = x
    x = MaxPooling2D((2, 2), strides=(2, 2), name='block5_pool')(x)
    x = conv_block_simple(x, 512, "conv_center")

    up6 = concatenate([UpSampling2D(name="up6")(x), conv5], axis=-1)
    conv6 = conv_block_simple(up6, 256, "conv6_1")
    conv6 = conv_block_simple(conv6, 256, "conv6_2")

    up7 = concatenate([UpSampling2D(name="up7")(conv6), conv4], axis=-1)
    conv7 = conv_block_simple(up7, 256, "conv7_1")
    conv7 = conv_block_simple(conv7, 256, "conv7_2")

    up8 = concatenate([UpSampling2D(name="up8")(conv7), conv3], axis=-1)
    conv8 = conv_block_simple(up8, 128, "conv8_1")
    conv8 = conv_block_simple(conv8, 128, "conv8_2")

    up9 = concatenate([UpSampling2D(name="up9")(conv8), conv2], axis=-1)
    conv9 = conv_block_simple(up9, 64, "conv9_1")
    conv9 = conv_block_simple(conv9, 64, "conv9_2")

    up10 = concatenate([UpSampling2D(name="up10")(conv9), conv1], axis=-1)
    conv10 = conv_block_simple(up10, 32, "conv10_1")
    conv10 = conv_block_simple(conv10, 32, "conv10_2")
    x = SpatialDropout2D(0.5)(conv10)
    x = Conv2D(1, (1, 1), activation="sigmoid")(x)
    model = Model(img_input, x)
    weights_path = get_file('vgg16_weights_tf_dim_ordering_tf_kernels_notop.h5',
                            WEIGHTS_PATH_NO_TOP,
                            cache_subdir='models',
                            file_hash='6d6bbae143d832006294945121d1f1fc')
    model.load_weights(weights_path, by_name=True)
    if input_shape[-1] > 3:
        conv1_weights = np.zeros((3, 3, input_shape[-1], 64), dtype="float32")
        vgg = VGG16(include_top=False, input_shape=(224, 224, 3))
        conv1_weights[:, :, :3, :] = vgg.get_layer("block1_conv1").get_weights()[0][:, :, :, :]
        bias = vgg.get_layer("block1_conv1").get_weights()[1]
        model.get_layer('block1_conv1_changed').set_weights((conv1_weights, bias))

    return model


def make_model(network, input_shape):
    if network == 'unet_vgg':
        return unet_vgg(input_shape)
    elif network == 'linknet':
        return LinkNet(input_shape)
    elif network == 'linknet_subpixel':
        return LinkNet(input_shape, subpixel=True, pretrained_weights=args.pretrained_weights)
    elif network == 'linknet_subpixel_conv1':
        return LinkNet(input_shape, subpixel=True, skipConnectionConv1=True)
    elif network == 'linknet_conv1':
        return LinkNet(input_shape, subpixel=False, skipConnectionConv1=True)
    else:
        raise ValueError('unknown network ' + network)


if __name__ == '__main__':
    unet_vgg((384, 384, 4)).summary()
