import os

from scipy import ndimage
import numpy as np

from postprocessing import label_watershed
from tools.rle import rle_to_string, rlencode

PREDICTION_DIR = 'images'

f_submit = open("output/all_trained_200.csv", "w")
threshold = 100
pixel_threshold = 200
for f in sorted(os.listdir(PREDICTION_DIR)):
    if not f.endswith(".png"):
        continue
    mask_img_path = os.path.join(PREDICTION_DIR, f)
    tile_id = f.split('_RGB.png')[0]
    mask_img = ndimage.imread(mask_img_path, mode='L')
    #mask_img[mask_img <= threshold] = 0
    #mask_img[mask_img > threshold] = 1
    labeled_array = label_watershed(mask_img, 127, 70, pixel_threshold)

    print("Tile: ", tile_id)
    print("Num houses: ", np.max(labeled_array))
    rle_str = rle_to_string(rlencode(labeled_array.flatten()))
    f_submit.write("{tile_id}\n2048,2048\n{rle}\n".format(tile_id=tile_id, rle=rle_str))
f_submit.close()