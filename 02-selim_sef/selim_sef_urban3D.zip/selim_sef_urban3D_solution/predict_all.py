import os

import numpy as np

from params import args
os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu

from postprocessing import label_watershed
from tools.rle import rle_to_string, rlencode

PRETRAINED_MODELS = 'pretrained_models'
TRAINED_MODELS = 'trained_models'

os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu

from PIL import Image
from keras.applications.imagenet_utils import preprocess_input
from keras.preprocessing.image import img_to_array, load_img
from tqdm import tqdm

from models import make_model
from tools.augment import do_tta, undo_tta
from tools.tiling import generate_tiles, combine_tiles

weights_dir = PRETRAINED_MODELS
new_trained_models = os.listdir(TRAINED_MODELS)
if len(new_trained_models) > 10:
    weights_dir = TRAINED_MODELS

images_dir = 'images'
test_dir = args.test_dir
submission_file = args.out_path + '.txt'

model_configs = [
    ('unet_vgg', 'triple_border_bce_dice', 'caffe', 2),
    ('unet_vgg', 'bce_dice', 'caffe', 2),
    ('linknet', 'bce_dice', 'tf', 1),
    ('linknet_subpixel_conv1', 'bce_dice', 'tf', 1),
    ('linknet_conv1', 'bce_dice', 'tf', 1),
    ('linknet_subpixel', 'bce_dice', 'tf', 1),
]
ttas = [None, 'hflip']

filenames = [f for f in sorted(os.listdir(test_dir)) if f.endswith("RGB.tif")][:]
all_weights = sorted(os.listdir(weights_dir))
all_preds = []
for (network, loss, preprocessing, parts) in model_configs:
    print("predict for {} models trained with loss {}".format(network, loss))
    model = make_model(network, (None, None, 4))
    allmodel_preds = []
    for weights in [w for w in all_weights if w.startswith(network + "_" + loss)]:
        masks = []
        model.load_weights(os.path.join(weights_dir, weights))
        for f in tqdm(filenames):
            preds = []
            ori_img = img_to_array(load_img(os.path.join(test_dir, f)))
            dsm = np.array(Image.open(os.path.join(test_dir, f.split("RGB.tif")[0] + "DSM.tif")))
            dtm = np.array(Image.open(os.path.join(test_dir, f.split("RGB.tif")[0] + "DTM.tif")))
            if preprocessing == 'caffe':
                dsm = (dsm - dtm) - 4.32
            else:
                dsm = np.clip((dsm - dtm) - 4.32, -50, 50) / 50
            image = ori_img
            new_image = np.zeros((image.shape[0], image.shape[1], 4), dtype="float32")
            new_image[:, :, :3] = preprocess_input(image, mode=preprocessing)

            new_image[..., 3] = dsm
            ori_img = new_image
            for tta in ttas:
                ttas = []
                if tta:
                    ttas = tta.split("+")
                img = do_tta(ori_img, ttas)

                tile_size = 2048
                tiles = generate_tiles(img, tile_size=tile_size)

                pred_tiles = model.predict(tiles, batch_size=1, verbose=0)
                pred = combine_tiles(pred_tiles, tile_size=tile_size, height=2048, width=2048)
                pred = undo_tta(pred, ttas)
                preds.append(pred)
            avg_mask = np.average(np.array(preds), axis=0)
            masks.append(avg_mask)
        if len(masks) > 0:
            allmodel_preds.append(np.array(masks))
    if len(allmodel_preds) > 0:
        allmodel_preds = np.average(allmodel_preds, axis=0)
        for p in range(parts):
            all_preds.append(allmodel_preds)

pixel_threshold = 200
all_preds = np.average(all_preds, axis=0)
f_submit = open(submission_file, "w")
for i, mask in enumerate(all_preds):
    labeled_array = label_watershed(mask * 255, 127, 70, pixel_threshold)
    rle_str = rle_to_string(rlencode(labeled_array.flatten()))
    tile_id = filenames[i][:-8]
    f_submit.write("{tile_id}\n2048,2048\n{rle}\n".format(tile_id=tile_id, rle=rle_str))