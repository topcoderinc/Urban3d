import keras.backend as K
from keras.backend.tensorflow_backend import _to_tensor
import numpy as np


def dice_coef_clipped(y_true, y_pred, smooth=1.0):
    y_true_f = K.flatten(K.round(y_true))
    y_pred_f = K.flatten(K.round(y_pred))
    intersection = K.sum(y_true_f * y_pred_f)
    return 100. * (2. * intersection + smooth) / (K.sum(y_true_f) + K.sum(y_pred_f) + smooth)


def jaccard_distance_loss(y_true, y_pred, smooth=1.):
    return 1. - jaccard_distance(y_true, y_pred, smooth)


def jaccard_distance(y_true, y_pred, smooth=1.):
    d = dice_coef(y_true, y_pred, smooth)
    return d / (2 - d)


def jaccard(y_true, y_pred, smooth=1.):
    d = dice_coef(K.round(y_true), K.round(y_pred), smooth)
    return d / (2 - d)


def dice_coef(y_true, y_pred, smooth=1.0):
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    intersection = K.sum(y_true_f * y_pred_f)
    return K.mean((2. * intersection + smooth) / (K.sum(y_true_f) + K.sum(y_pred_f) + smooth))


def get_border_mask(pool_size, y_true):
    negative = 1 - y_true
    positive = y_true
    positive = K.pool2d(positive, pool_size=pool_size, padding="same")
    negative = K.pool2d(negative, pool_size=pool_size, padding="same")
    border = positive * negative
    return border


def border_bce_loss(y_true, y_pred):
    border = get_border_mask((4, 4), y_true)
    margins_loss = K.mean(K.binary_crossentropy(K.flatten(y_true), K.flatten(y_pred)) * K.flatten(border))
    return margins_loss


def inside_border_loss(y_true, y_pred):
    negative = 1 - y_true
    positive = y_true
    thin_margins = get_between_elements_border(negative, positive)
    thin_objects = get_between_elements_border(positive, negative)

    margins_loss = K.mean(K.binary_crossentropy(K.flatten(y_true), K.flatten(y_pred)) * K.flatten(thin_margins))
    # objects_loss = K.mean(K.binary_crossentropy(K.flatten(y_true), K.flatten(y_pred)) * K.flatten(thin_objects))
    return margins_loss


def get_between_elements_border(negative, positive):
    structure = np.asarray(np.zeros((3, 3, 1)), dtype="float32")
    filter = K.tf.constant(structure, dtype="float32")
    dilation = positive
    dilation = K.tf.nn.dilation2d(input=dilation, strides=[1, 1, 1, 1], rates=[1, 5, 5, 1], filter=filter, padding='SAME')
    erosion = dilation
    erosion = K.tf.nn.erosion2d(erosion, strides=[1, 1, 1, 1], rates=[1, 5, 5, 1], kernel=filter, padding='SAME')
    border = erosion * negative
    return border


def bootstrapped_crossentropy(y_true, y_pred, bootstrap_type='hard', alpha=0.95):
    target_tensor = y_true
    prediction_tensor = y_pred
    _epsilon = _to_tensor(K.epsilon(), prediction_tensor.dtype.base_dtype)
    prediction_tensor = K.tf.clip_by_value(prediction_tensor, _epsilon, 1 - _epsilon)
    prediction_tensor = K.tf.log(prediction_tensor / (1 - prediction_tensor))

    if bootstrap_type == 'soft':
        bootstrap_target_tensor = alpha * target_tensor + (1.0 - alpha) * K.tf.sigmoid(prediction_tensor)
    else:
        bootstrap_target_tensor = alpha * target_tensor + (1.0 - alpha) * K.tf.cast(
            K.tf.sigmoid(prediction_tensor) > 0.5, K.tf.float32)
    return K.mean(K.tf.nn.sigmoid_cross_entropy_with_logits(
        labels=bootstrap_target_tensor, logits=prediction_tensor))


def dice_coef_loss(y_true, y_pred):
    return 1 - dice_coef(y_true, y_pred)


def dice_coef_loss_bce(y_true, y_pred, dice=0.5, bce=0.5, bootstrapping='hard', alpha=1.):
    return bootstrapped_crossentropy(y_true, y_pred, bootstrapping, alpha) * bce + dice_coef_loss(y_true, y_pred) * dice


def binary_crossentropy(y, p):
    return K.mean(K.binary_crossentropy(y, p))


def make_loss(loss_name):
    if loss_name == 'crossentropy':
        return binary_crossentropy
    elif loss_name == 'crossentropy_boot':
        def loss(y, p):
            return bootstrapped_crossentropy(y, p, 'hard', 0.9)

        return loss
    elif loss_name == 'categorical_crossentropy':
        return K.categorical_crossentropy
    elif loss_name == 'dice':
        return dice_coef_loss
    elif loss_name == 'jaccard':
        return jaccard_distance_loss
    elif loss_name == 'bce_dice':
        def loss(y, p):
            return dice_coef_loss_bce(y, p, dice=0.3, bce=0.7, bootstrapping='soft', alpha=1)

        return loss
    elif loss_name == 'border_bce_dice':
        def loss(y, p):
            return inside_border_loss(y, p) + dice_coef_loss_bce(y, p, dice=0.3, bce=0.7, bootstrapping='soft', alpha=1)

        return loss
    elif loss_name == 'triple_border_bce_dice':
        def loss(y, p):
            return 3 * inside_border_loss(y, p) + dice_coef_loss_bce(y, p, dice=0.3, bce=0.7, bootstrapping='soft', alpha=1)

        return loss

    elif loss_name == 'pool_border_loss':
        def loss(y, p):
            return 3 * border_bce_loss(y, p) + dice_coef_loss_bce(y, p, dice=0.3, bce=0.7, bootstrapping='soft', alpha=1)

        return loss

    elif loss_name == 'boot_soft':
        def loss(y, p):
            return dice_coef_loss_bce(y, p, dice=0.5, bce=0.5, bootstrapping='soft', alpha=0.9)

        return loss
    elif loss_name == 'boot_hard':
        def loss(y, p):
            return dice_coef_loss_bce(y, p, dice=0.3, bce=0.7, bootstrapping='hard', alpha=0.8)

        return loss
    else:
        ValueError("Unknown loss.")
