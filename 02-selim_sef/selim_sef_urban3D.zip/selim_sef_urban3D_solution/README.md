
## Solution to Urban3D, handle: selim_sef 
## TODO: add documentation