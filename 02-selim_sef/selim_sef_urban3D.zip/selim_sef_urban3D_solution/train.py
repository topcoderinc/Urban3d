import gc
import os
from params import args

os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu

import numpy as np

from models import make_model

from datasets.urban3d import generate_ids, Urban3DIteratorWithDSMCorrected
from tools.clr import CyclicLR

from tools.augment import RandomTransformer

from keras.callbacks import Callback
from keras.losses import binary_crossentropy
from keras.optimizers import RMSprop

from losses import make_loss, dice_coef_clipped

from params import args


def freeze_model(model, freeze_before_layer):
    if freeze_before_layer == "ALL":
        for l in model.layers:
            l.trainable = False
    else:
        freeze_before_layer_index = -1
        for i, l in enumerate(model.layers):
            if l.name == freeze_before_layer:
                freeze_before_layer_index = i
        for l in model.layers[:freeze_before_layer_index]:
            l.trainable = False


class SaveEpochsCallback(Callback):
    def __init__(self,
                 model_type,
                 loss_type,
                 epochs,
                 model_file_template='{models_dir}/{alias}{model_type}_{loss_type}_{epoch:d}.h5'
                 ):
        super().__init__()
        self.epochs = epochs
        self.model_type = model_type
        self.loss_type = loss_type
        self.model_file_template = model_file_template

    def on_train_begin(self, logs={}):
        return

    def on_train_end(self, logs={}):
        return

    def on_epoch_begin(self, epoch, logs={}):
        return

    def on_epoch_end(self, epoch, logs={}):
        alias = ""
        if args.alias:
            alias = args.alias
        if epoch in self.epochs:
            filepath = self.model_file_template.format(models_dir=args.models_dir,alias=alias, model_type=self.model_type, loss_type=self.loss_type, epoch=epoch + 1)
            self.model.save_weights(filepath, overwrite=True)
        return

    def on_batch_begin(self, batch, logs={}):
        return

    def on_batch_end(self, batch, logs={}):
        return

def train_models():
    if args.crop_size:
        print('Using crops of shape ({}, {})'.format(args.crop_size, args.crop_size))
    else:
        print('Using full size images')
    all_ids = np.array(generate_ids(args.img_dir))
    np.random.seed(args.seed)
    model = make_model(args.network, (None, None, 4))
    print('Training model {}, on {} images, with loss function {} and preprocessing mode {}'
          .format(args.network,
                  len(all_ids),
                  args.loss_function,
                  args.preprocessing_function))
    if args.weights is None:
        print('No weights passed, training from scratch')
    else:
        print('Loading weights from {}'.format(args.weights))
        model.load_weights(args.weights)

    if args.freeze_till_layer:
        print("Freezing model till layer {}".format(args.freeze_till_layer))
        freeze_model(model, args.freeze_till_layer)

    optimizer = RMSprop(lr=args.learning_rate)

    model.compile(loss=make_loss(args.loss_function),
                  optimizer=optimizer,
                  metrics=[binary_crossentropy, dice_coef_clipped])

    train_generator = Urban3DIteratorWithDSMCorrected(
        data_dir=args.img_dir,
        mask_dir=args.mask_dir,
        batch_size=args.batch_size,
        image_ids=all_ids,
        resize=None,
        crops_per_image=args.crops_per_image,
        crop_shape=(args.crop_size, args.crop_size),
        random_transformer=RandomTransformer(horizontal_flip=True, vertical_flip=True, channel_shift_range=0.1)
    )

    if args.save_epochs == 'ALL':
        save_epochs = range(args.epochs)
    else:
        save_epochs = [int(e) for e in args.save_epochs.split(",")]

    callbacks = [SaveEpochsCallback(model_type=args.network, loss_type=args.loss_function, epochs=save_epochs)]
    if args.clr is not None:
        clr_params = args.clr.split(',')
        base_lr = float(clr_params[0])
        max_lr = float(clr_params[1])
        step = int(clr_params[2])
        mode = clr_params[3]
        clr = CyclicLR(base_lr=base_lr, max_lr=max_lr, step_size=step, mode=mode)
        callbacks.append(clr)
    steps_per_epoch = len(all_ids) / args.batch_size + 1
    if args.steps_per_epoch:
        steps_per_epoch = args.steps_per_epoch

    model.fit_generator(
        train_generator,
        steps_per_epoch=steps_per_epoch,
        epochs=args.epochs,
        callbacks=callbacks,
        max_queue_size=200,
        verbose=1,
        workers=7)


if __name__ == '__main__':
    train_models()
