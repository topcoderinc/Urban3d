from scipy import ndimage


def transform(mask, max_width):
    labels = mask
    negative_labels = 1 - mask
    distance_transform = ndimage.distance_transform_edt(labels)
    distance_transform[distance_transform > max_width] = max_width

    negative_distance_transform = ndimage.distance_transform_edt(negative_labels)
    negative_distance_transform[negative_distance_transform > max_width] = max_width

    return distance_transform - negative_distance_transform