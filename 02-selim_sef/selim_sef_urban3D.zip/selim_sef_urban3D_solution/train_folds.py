import gc
import os

import numpy as np

from metrics.urban3dmetric import calculate_f1_buildings_score
from params import args
from tools.misc import dice
from tools.tiling import generate_tiles, combine_tiles

os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu
from datasets.urban3d import generate_ids, Urban3DIteratorWithDSMCorrected
from tools.clr import CyclicLR

from sklearn.model_selection._split import KFold

from tools.augment import RandomTransformer


from keras.callbacks import ModelCheckpoint, EarlyStopping, Callback
from keras.losses import binary_crossentropy
from keras.optimizers import RMSprop

from losses import make_loss, jaccard
from models import make_model
from params import args
import keras.backend as K

def freeze_model(model, freeze_before_layer):
    if freeze_before_layer == "ALL":
        for l in model.layers:
            l.trainable = False
    else:
        freeze_before_layer_index = -1
        for i, l in enumerate(model.layers):
            if l.name == freeze_before_layer:
                freeze_before_layer_index = i
        for l in model.layers[:freeze_before_layer_index]:
            l.trainable = False

class ValidationCallback(Callback):
    def __init__(self, validation_data, tile_ids):
        super().__init__()
        self.x_val = validation_data[0]
        self.y_val = validation_data[1]
        self.tile_ids = tile_ids

    def on_train_begin(self, logs={}):
        return

    def on_train_end(self, logs={}):
        return

    def on_epoch_begin(self, epoch, logs={}):
        return

    def on_epoch_end(self, epoch, logs={}):
        preds = []
        for i in range(len(self.x_val)):
            tiles = generate_tiles(self.x_val[i], tile_size=1024)
            pred_tiles = self.model.predict(tiles, batch_size=1)
            height = 2048
            width = 2048
            if args.resize:
                size = [int(i) for i in args.resize.split(",")]
                height = size[0]
                width = size[1]
            pred = combine_tiles(pred_tiles, tile_size=1024, height=height, width=width)
            preds.append(pred)
        y_pred = np.array(preds)
        y_true = np.array(self.y_val)
        logs['val_fscore'] = calculate_f1_buildings_score(y_true, y_pred)
        print("\nVal f_score = {val_fscore:0.7f}\r".format(val_fscore=logs['val_fscore']))

        y_pred = y_pred.round()
        dices = []
        for i in range(len(y_pred)):
            dices.append(dice(y_pred, y_true))
        logs['val_dice'] = np.array(dices).mean()
        print("\nVal dice = {val_dice:0.7f}\r".format(val_dice=logs['val_dice']))
        return

    def on_batch_begin(self, batch, logs={}):
        return

    def on_batch_end(self, batch, logs={}):
        return

def main():


    if args.crop_size:
        print('Using crops of shape ({}, {})'.format(args.crop_size, args.crop_size))
    else:
        print('Using full size images')

    all_ids_all = np.array(generate_ids(args.img_dir))
    np.random.seed(args.seed)
    all_ids = all_ids_all
    kfold = KFold(n_splits=args.n_folds, shuffle=True)

    splits = [s for s in kfold.split(all_ids)]
    folds = [ int(f) for f in args.fold.split(",")]
    for fold in folds:
        best_model_file = \
            '{}/{}_{}_loss-{}-fold_{}-{:.6f}'.format(args.models_dir, args.alias, args.network, args.loss_function, fold, args.learning_rate) + \
            '-{epoch:d}-{val_fscore:0.7f}-{val_dice:0.7f}.h5'

        model = make_model(args.network, (None, None, 4))

        if args.weights is None:
            print('No weights passed, training from scratch')
        else:
            print('Loading weights from {}'.format(args.weights))
            model.load_weights(args.weights, by_name=True)
        freeze_model(model, args.freeze_till_layer)

        optimizer = RMSprop(lr=args.learning_rate)

        model.compile(loss=make_loss(args.loss_function),
                      optimizer=optimizer,
                      metrics=[binary_crossentropy, jaccard])

        train_ind, test_ind = splits[fold]
        train_ids = all_ids[train_ind]
        val_ids = all_ids[test_ind]
        print('Training fold #{}, {} in train_ids, {} in val_ids'.format(fold, len(train_ids), len(val_ids)))

        resize = None
        if args.resize:
            resize = [int(i) for i in args.resize.split(",")]
        train_generator = Urban3DIteratorWithDSMCorrected(
            data_dir=args.img_dir,
            mask_dir=args.mask_dir,
            batch_size=args.batch_size,
            image_ids=train_ids,
            resize=resize,
            crops_per_image=args.crops_per_image,
            crop_shape=(args.crop_size, args.crop_size),
            random_transformer=RandomTransformer(horizontal_flip=True, vertical_flip=True, channel_shift_range=0.05)
        )

        val_generator = Urban3DIteratorWithDSMCorrected(
            data_dir=args.img_dir,
            mask_dir=args.mask_dir,
            batch_size=1,
            resize=resize,
            image_ids=val_ids,
            crop_shape=None,
            shuffle=False,
            random_transformer=None
        )

        x_val = []
        y_val = []
        for i in range(len(val_ids)):
            x, y = val_generator[i]
            x_val.append(x)
            y_val.append(y)

        x_val = np.concatenate(x_val, axis=0)
        y_val = np.concatenate(y_val, axis=0)
        val_callback = ValidationCallback((x_val, y_val), val_ids)

        best_model = ModelCheckpoint(best_model_file, monitor='val_fscore',
                                     verbose=1,
                                     save_best_only=False,
                                     save_weights_only=True)

        callbacks = [val_callback, best_model, EarlyStopping(patience=20, verbose=1, monitor='val_fscore', mode='max')]
        if args.clr is not None:
            clr_params = args.clr.split(',')
            base_lr = float(clr_params[0])
            max_lr = float(clr_params[1])
            step = int(clr_params[2])
            mode = clr_params[3]
            clr = CyclicLR(base_lr=base_lr, max_lr=max_lr, step_size=step, mode=mode)
            callbacks.append(clr)

        steps_per_epoch = len(all_ids) / args.batch_size + 1
        if args.steps_per_epoch:
            steps_per_epoch = args.steps_per_epoch

        model.fit_generator(
            train_generator,
            steps_per_epoch=steps_per_epoch,
            epochs=args.epochs,
            callbacks=callbacks,
            max_queue_size=50,
            verbose=1,
            workers=4)

        del model
        K.clear_session()
        gc.collect()


if __name__ == '__main__':
    main()
