import os
import sys
import shutil

DATASET_NAME = sys.argv[1] 

STRIDE = sys.argv[2] 

DATASET_SUBTYPES = ['rgb', 'gtc', 'dmd']

for current_dataset_subtype in DATASET_SUBTYPES:
    try:
        shutil.rmtree(os.path.join(DATASET_NAME, current_dataset_subtype, str(STRIDE)))
    except:
        pass
