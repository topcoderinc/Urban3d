import os
import sys
import shutil

DATASET_NAME = sys.argv[1] 

SUFFIX = sys.argv[2] 

DATASETS_TYPES = ['training', 'validation']

DATASET_SUBTYPES = ['rgb', 'gtc', 'dmd']

for current_dataset_type in DATASETS_TYPES:
    for current_dataset_subtype in DATASET_SUBTYPES:
        shutil.rmtree(os.path.join(DATASET_NAME, current_dataset_type, current_dataset_subtype, str(SUFFIX)))
