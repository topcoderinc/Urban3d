import os
import cv2 as cv
import numpy as np
from sklearn.metrics import f1_score
import skimage
import glob
import multiprocessing as mp
import sys
from PIL import Image


GT_IMAGES_LOCATION = sys.argv[1]

NN_IMAGES_LOCATION = sys.argv[2]

thresholds = [x/20. for x in range(1, 20)]

paths = glob.glob(NN_IMAGES_LOCATION + '/*.png')

all_f1_scores=[]
       
def compute_score_for_threshold(current_threshold):
    num_evaluated_images = 0
    global_f1_score = 0
    for current_image_path in paths:
        try:
            current_nn_output = cv.imread(current_image_path, 1)
            current_nn_output = current_nn_output[:,:,0]
            no_gti_name = os.path.basename(current_image_path)
            mask_name = no_gti_name.replace('.png', '_GTC.png')

            current_image_PIL = Image.open(os.path.join(GT_IMAGES_LOCATION, mask_name)).convert('L')
            current_gt_binary = np.array(current_image_PIL) > 125
            if np.max(np.max(current_gt_binary)) == False:
                continue

            current_nn_output_thresholded = current_nn_output / (np.max(np.max(current_nn_output)) + np.spacing(1))

            current_nn_output_thresholded = current_nn_output_thresholded > current_threshold

            current_f1_score = f1_score(current_nn_output_thresholded.ravel(), current_gt_binary.ravel())

            global_f1_score += current_f1_score
            
            num_evaluated_images += 1
        except:
            pass
        
    global_f1_score /= num_evaluated_images
    
    return global_f1_score

p = mp.Pool(8)
all_f1_scores = p.map(compute_score_for_threshold, thresholds)

best_f1_index = np.argmax(all_f1_scores)

print(thresholds[best_f1_index])
