import os
import cv2 as cv
import numpy as np
from sklearn.metrics import f1_score
import skimage
import glob
import multiprocessing as mp
import sys

NN_IMAGES_LOCATION = sys.argv[1]

THRESHOLD =  sys.argv[2]

THRESHOLDED_DESTINATION =  sys.argv[3]

if len(sys.argv) > 4:
    SUFFIX = sys.argv[4]
else:
    SUFFIX = ''

if not os.path.exists(THRESHOLDED_DESTINATION):
    os.makedirs(THRESHOLDED_DESTINATION)

paths = glob.glob(NN_IMAGES_LOCATION + '/*.png')

def threshold_image(current_image_path):
	current_nn_output = cv.imread(current_image_path, 1)
	current_nn_output = current_nn_output[:,:,0]
	current_nn_output_thresholded = current_nn_output / (np.max(np.max(current_nn_output)) + np.spacing(1))
	current_nn_output_thresholded = current_nn_output_thresholded > float(THRESHOLD)
	cv.imwrite(os.path.join(THRESHOLDED_DESTINATION, os.path.basename(current_image_path.replace('.png', SUFFIX+'.png'))), skimage.img_as_ubyte(current_nn_output_thresholded))


p = mp.Pool(8)
all_f1_scores = p.map(threshold_image, paths)


