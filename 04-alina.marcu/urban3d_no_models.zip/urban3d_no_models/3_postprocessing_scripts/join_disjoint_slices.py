import os
import cv2 as cv
import numpy as np
import sys
import yaml 

SETTINGS_FILENAME = 'settings.yaml'

with open(SETTINGS_FILENAME, 'r') as f:
    settings = yaml.load(f)


SLICES_LOCATION = sys.argv[1]

JOINED_LOCATION = sys.argv[2]

CELL_STEP_X = 1024
CELL_STEP_Y = 1024

X_CELLS = 1
Y_CELLS = 1

SUBIMAGE_WIDTH = CELL_STEP_X * X_CELLS
SUBIMAGE_HEIGHT = CELL_STEP_Y * Y_CELLS

OFFSET_POINT_X = CELL_STEP_X / 2
OFFSET_POINT_Y = CELL_STEP_Y / 2

if not os.path.exists(JOINED_LOCATION):
    os.makedirs(JOINED_LOCATION)

paths = (os.path.join(root, filename)
         for root, _, filenames in os.walk(SLICES_LOCATION)
         for filename in filenames)

if __name__ == '__main__':
    seenBaseImages = []
    start_x_indices = {}
    start_y_indices = {}
    for currentPath in paths:
        if '.npy' in currentPath:
            continue
        if 'bw_masks' in currentPath:
            continue            
        
        pathNoFilename, filename = os.path.split(currentPath)
        splitHelper = filename.split('_')
        currentBaseImage = splitHelper[0] + '_' + splitHelper[1] + '_' + splitHelper[2]
        if currentBaseImage not in seenBaseImages:
            seenBaseImages.append(currentBaseImage)
            currentTileStartX, currentTileStartY = splitHelper[3], splitHelper[4].split('.')[0]
            currentTileStartX = int(currentTileStartX) - 1 
            currentTileStartY = int(currentTileStartY) - 1 
            start_x_indices[currentBaseImage] = []
            start_y_indices[currentBaseImage] = []
            start_x_indices[currentBaseImage].append(currentTileStartX)
            start_y_indices[currentBaseImage].append(currentTileStartY)
        else:
            # decide whether x or y tile
            currentTileStartX, currentTileStartY = splitHelper[3], splitHelper[4].split('.')[0]
            currentTileStartX = int(currentTileStartX) - 1 
            currentTileStartY = int(currentTileStartY) - 1 
            start_x_indices[currentBaseImage].append(currentTileStartX)
            start_y_indices[currentBaseImage].append(currentTileStartY)

    for currentBaseImage in seenBaseImages:
        max_x = np.max(start_x_indices[currentBaseImage]) + CELL_STEP_X
        max_y = np.max(start_y_indices[currentBaseImage]) + CELL_STEP_Y
        currentLabelImage = np.zeros((max_x, max_y, 3), dtype=np.uint8)
        for currentTileIndex in range(len(start_x_indices[currentBaseImage])):
            currentSubImage = cv.imread(os.path.join(SLICES_LOCATION, currentBaseImage + '_' +
                                                     str(start_x_indices[currentBaseImage][currentTileIndex]+1) + '_' +
                                                     str(start_y_indices[currentBaseImage][currentTileIndex]+1) + '.png')) 
            
            currentLabelImage[start_x_indices[currentBaseImage][currentTileIndex]:start_x_indices[currentBaseImage][currentTileIndex] + SUBIMAGE_WIDTH,
                      start_y_indices[currentBaseImage][currentTileIndex]:start_y_indices[currentBaseImage][currentTileIndex] + SUBIMAGE_HEIGHT] = currentSubImage
        cv.imwrite(os.path.join(JOINED_LOCATION, currentBaseImage+'.png'), currentLabelImage)
