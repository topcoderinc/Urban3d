import os
import cv2 as cv
import numpy as np
from PIL import Image
import skimage
from skimage.measure import label
from skimage.color import label2rgb
from skimage.measure import regionprops
from sklearn.metrics import jaccard_similarity_score
from skimage.morphology import remove_small_objects
import mahotas
import multiprocessing as mp
import sys

NN_OUTPUT_LOCATION = sys.argv[1]

DESTINATION_LOCATION = '/data'

MIN_HOUSE_AREA = 100

MAX_AREA_FOR_DILATION = 0

MIN_AREA_FOR_HOLE_FILLING = 3000

DESTINATION_RLE_FILENAME = sys.argv[2]

paths = (os.path.join(root, filename)
         for root, _, filenames in os.walk(NN_OUTPUT_LOCATION)
         for filename in filenames)
         
if not os.path.exists(os.path.dirname(DESTINATION_RLE_FILENAME)):
    os.makedirs(os.path.dirname(DESTINATION_RLE_FILENAME))

dest_file = open(DESTINATION_RLE_FILENAME, 'w')
        
for current_nn_path in paths:
    print(current_nn_path)
    current_nn_image = cv.imread(current_nn_path, 0) > 0
    start_index = 1
    nn_labeled = label(current_nn_image, background=0)
    print('min nn labeled', np.min(np.min(nn_labeled)))
    out_image = label2rgb(nn_labeled, bg_label=0, bg_color=(0,0,0))
    final_gt = np.zeros_like(current_nn_image, dtype=np.uint8)
    current_instance_labeled_image = np.zeros_like(current_nn_image, dtype=np.int64)
    has_failed = False
    for region in regionprops(nn_labeled):
        if region.area < MIN_HOUSE_AREA:
            continue

        # find best match - probably the most wasteful stuff coded today
        nn_with_current_region = np.zeros_like(current_nn_image)
        
        # remove spurrious pixels
        if region.area < MIN_AREA_FOR_HOLE_FILLING:
            region_image = remove_small_objects(region.image, min_size = MIN_HOUSE_AREA, connectivity = 1)
            nn_with_current_region[region.bbox[0]:region.bbox[2], region.bbox[1]:region.bbox[3]] = region_image
        else:
            region_filled_image = remove_small_objects(region.filled_image, min_size = MIN_HOUSE_AREA, connectivity = 1)
            nn_with_current_region[region.bbox[0]:region.bbox[2], region.bbox[1]:region.bbox[3]] = region_filled_image            
        if region.area > MAX_AREA_FOR_DILATION:
            final_gt[np.greater(nn_with_current_region,0)] = 0
            final_gt += nn_with_current_region
            current_instance_labeled_image[np.greater(nn_with_current_region,0)] = 0
            current_instance_labeled_image += nn_with_current_region * start_index
            start_index += 1
            continue
       
    if has_failed == True:
        print("failed")
        break
        
    out_image2 = label2rgb(current_instance_labeled_image, bg_label=0, bg_color=(0,0,0))
        
    tile_id = os.path.basename(current_nn_path).split('.')[0]
    dest_file.write(tile_id + '\n')
    dest_file.write("{0},{1}\n".format(current_nn_image.shape[0], current_nn_image.shape[1]))
    current_instance_labeled_vector = current_instance_labeled_image.flatten()
    previous_value = 0
    counter = 0
    is_first_value = True
    for current_value in current_instance_labeled_vector:
        if current_value == previous_value:
            counter+=1
        else:
            if is_first_value:
                dest_file.write("{0},{1}".format(previous_value, counter))
                is_first_value = False
            else:
                dest_file.write(",{0},{1}".format(previous_value, counter))
            previous_value = current_value
            counter = 1
    dest_file.write('\n')


        
    

