import os
import cv2 as cv
import numpy as np
from PIL import Image
import skimage
from skimage.measure import label
from skimage.color import label2rgb
from skimage.measure import regionprops
from sklearn.metrics import jaccard_similarity_score
from skimage.morphology import remove_small_objects
from skimage.morphology import binary_erosion
from skimage.morphology import binary_dilation
import mahotas
import multiprocessing as mp


NN_OUTPUT_LOCATION = '/nvme-nets/misc/topcoder/aws_keras/training_scripts/weights/finetune_iteration_1_rgb_dmd_lr_10-5_20171203/results_epoch_11/TEST_62/joined_disjoint_slices_1024_thresholded_0.5'
RESULTS_LOCATION = '/nvme-nets/misc/topcoder/aws_keras/training_scripts/weights/finetune_iteration_1_rgb_dmd_lr_10-5_20171203/results_epoch_11/TEST_62/joined_disjoint_slices_1024_thresholded_0.5_split_instances_after_competition_20171205'

MIN_HOUSE_AREA = 100

MAX_AREA_FOR_DILATION = 0

MIN_AREA_FOR_HOLE_FILLING = 3000

MIN_HOLES_TO_FILLED_AREA_RATIO = 0.3

MAX_HOLES_TO_FILLED_AREA_RATIO = 0.9

DESTINATION_RLE_FILENAME = 'split_instances_REMOVE_SPUR_PIXELS_min_area_' + str(MIN_HOUSE_AREA) + '_FILL_BIG_HOLES_RATIO_' + str(MIN_HOLES_TO_FILLED_AREA_RATIO) + '_thresh_0.5_EPOCH_11_iteration_1.txt'

paths = (os.path.join(root, filename)
         for root, _, filenames in os.walk(NN_OUTPUT_LOCATION)
         for filename in filenames)

if not os.path.exists(RESULTS_LOCATION):
    os.makedirs(RESULTS_LOCATION)

dest_file = open(os.path.join(RESULTS_LOCATION, DESTINATION_RLE_FILENAME), 'w')
        

for current_nn_path in paths:
    current_nn_image = cv.imread(current_nn_path, 0) > 0
    start_index = 1
    
    nn_labeled = label(current_nn_image, background=0)
    
    label2rgb_out_image = label2rgb(nn_labeled, bg_label=0, bg_color=(0,0,0))
    cv.imwrite(os.path.join(RESULTS_LOCATION, os.path.basename(current_nn_path)), label2rgb_out_image * 255)
    
    final_gt = np.zeros_like(current_nn_image, dtype=np.uint8)
    # Used for rle
    current_instance_labeled_image = np.zeros_like(current_nn_image, dtype=np.int64)
    has_failed = False
    for region in regionprops(nn_labeled):
        if region.area < MIN_HOUSE_AREA:
            continue

        # find best match - probably the most wasteful stuff coded today
        current_region = np.zeros_like(current_nn_image, dtype=np.uint8)
        current_region[region.bbox[0]:region.bbox[2], region.bbox[1]:region.bbox[3]]  = region.image 
        #print(current_region.shape)
        was_split = False
        for current_erode_kernel in range(1,12,2):
            #print('current_erode_kernel: ' + str(current_erode_kernel))
            #print(current_region.shape)
            current_region_eroded = binary_erosion(current_region, selem=np.ones((current_erode_kernel, current_erode_kernel)))
            #print(current_region_eroded.shape)
            current_region_eroded_labeled =label(current_region_eroded)

            current_regions = regionprops(current_region_eroded_labeled)
            num_regions = len(current_regions)
            #print('num regions', num_regions)
            if num_regions > 1:
                # check percentage
                #current_areas = [region.area for region in current_regions]
                for split_region in current_regions:
                    nn_with_current_region = np.zeros_like(current_nn_image)
                    #current_region_split = np.bitwise_and(current_nn_image[split_region.bbox[0]:split_region.bbox[2], split_region.bbox[1]:split_region.bbox[3]], binary_dilation(split_region.image, selem=np.ones((current_erode_kernel, current_erode_kernel))))
                    current_region_split = current_nn_image[split_region.bbox[0]:split_region.bbox[2], split_region.bbox[1]:split_region.bbox[3]]
                    #can split
                    current_region_split = remove_small_objects(current_region_split, min_size = MIN_HOUSE_AREA, connectivity = 1)
                    #if np.count_nonzero(current_region_split) < MIN_HOUSE_AREA:
                    #    continue
                    nn_with_current_region[split_region.bbox[0]:split_region.bbox[2], split_region.bbox[1]:split_region.bbox[3]] = current_region_split
                    
                    final_gt[np.greater(nn_with_current_region,0)] = 0
                    final_gt += nn_with_current_region
                    current_instance_labeled_image[np.greater(nn_with_current_region,0)] = 0
                    current_instance_labeled_image += nn_with_current_region * start_index
                    start_index += 1
                    print('was added')
                was_split = True
                print('was split')
                continue
        if was_split:
            continue
                    
        #cannot split
        nn_with_current_region = np.zeros_like(current_nn_image)

        region_image = remove_small_objects(region.image, min_size = MIN_HOUSE_AREA, connectivity = 1)
        nn_with_current_region[region.bbox[0]:region.bbox[2], region.bbox[1]:region.bbox[3]] = region_image
    

        final_gt[np.greater(nn_with_current_region,0)] = 0
        final_gt += nn_with_current_region
        current_instance_labeled_image[np.greater(nn_with_current_region,0)] = 0
        current_instance_labeled_image += nn_with_current_region * start_index
        start_index += 1

        """
        # dilate
        nn_with_current_region_dilated = mahotas.dilate(nn_with_current_region, DILATE_KERNEL)
        gt_with_current_region_sum = final_gt + nn_with_current_region_dilated
        #print(np.max(np.max(gt_with_current_region_sum)))
        overlapping_regions = np.greater(gt_with_current_region_sum, 1)
        if np.count_nonzero(overlapping_regions) > 0:
            #print(np.count_nonzero(overlapping_regions))
            #print(np.max(np.max(final_gt)))
            final_gt[np.greater(nn_with_current_region,0)] = 0
            final_gt += nn_with_current_region
            current_instance_labeled_image[np.greater(nn_with_current_region,0)] = 0
            current_instance_labeled_image += nn_with_current_region * start_index
            start_index += 1
            #print('add normal')
            if np.max(np.max(final_gt)) ==2:
                print("FAIL")
                has_failed = True
                break
        else:
            #print('add dilated')
            #print(np.max(np.max(final_gt)))
            final_gt += nn_with_current_region_dilated
            current_instance_labeled_image += nn_with_current_region_dilated * start_index
            start_index += 1
            #print(np.max(np.max(final_gt)))
        """
    if has_failed == True:
        print("failed")
        break
    
    print('min current_instance labeled', np.min(np.min(current_instance_labeled_image)))
    out_image2 = label2rgb(current_instance_labeled_image, bg_label=0, bg_color=(0,0,0))
    cv.imwrite(os.path.join(RESULTS_LOCATION, os.path.basename(current_nn_path.replace('.png', '_num_instances_'+str(start_index)+'_split.png'))), out_image2*255)
        
    tile_id = os.path.basename(current_nn_path).split('.')[0]
    dest_file.write(tile_id + '\n')
    dest_file.write("{0},{1}\n".format(current_nn_image.shape[0], current_nn_image.shape[1]))
    current_instance_labeled_vector = current_instance_labeled_image.flatten()
    previous_value = 0
    counter = 0
    is_first_value = True
    for current_value in current_instance_labeled_vector:
        if current_value == previous_value:
            counter+=1
        else:
            if is_first_value:
                dest_file.write("{0},{1}".format(previous_value, counter))
                is_first_value = False
            else:
                dest_file.write(",{0},{1}".format(previous_value, counter))
            previous_value = current_value
            counter = 1
    dest_file.write('\n')


        
    

