import os
import cv2 as cv
import numpy as np

#SLICES_LOCATION = '/nvme-nets/misc/topcoder/keras_Unet/results/UNET_only_RGB_dilated_conv_bce_dice_loss_test_on_testing_248_20171106_1_overlap_768/original'
SLICES_LOCATION = '/nvme-nets/misc/topcoder/data/validation/RGB_selected_14_sliced_1024_min_overlap_768_rotations'
#JOINED_LOCATION = '/nvme-nets/misc/topcoder/keras_Unet/results/UNET_only_RGB_dilated_conv_bce_dice_loss_test_on_testing_248_20171106_1_overlap_768/joined'
#JOINED_LOCATION='/nvme-nets/misc/topcoder/Mask_RCNN/output_testing_20171105_joined'
JOINED_LOCATION = '/nvme-nets/misc/topcoder/data/validation/RGB_selected_14_sliced_1024_min_overlap_768_rotations_joined_test'

ROTATION_ANGLES = [0, 90, -90, 180]

CELL_STEP_X = 1024
CELL_STEP_Y = 1024

X_CELLS = 1
Y_CELLS = 1

SUBIMAGE_WIDTH = CELL_STEP_X * X_CELLS
SUBIMAGE_HEIGHT = CELL_STEP_Y * Y_CELLS

OFFSET_POINT_X = CELL_STEP_X / 2
OFFSET_POINT_Y = CELL_STEP_Y / 2

JOIN_OPERATOR = 'MAX' # 'MULTIPLICATION', 'SUM'


def join_operator(img1, img2):
    print(img1.shape)
    print(img2.shape)
    if JOIN_OPERATOR == 'MAX':
        return np.maximum(img1, img2)
    elif JOIN_OPERATOR == 'SUM':
        return np.sum(img1, img2)
    elif JOIN_OPERATOR == 'MULTIPLICATION':
        return np.multiply(img1, img2)


if not os.path.exists(JOINED_LOCATION):
    os.makedirs(JOINED_LOCATION)

paths = (os.path.join(root, filename)
         for root, _, filenames in os.walk(SLICES_LOCATION)
         for filename in filenames)
		 
if __name__ == '__main__':
    seenBaseImages = []
    start_x_indices = {}
    start_y_indices = {}
    for currentPath in paths:
        if '.npy' in currentPath:
            continue
        if 'bw_masks' in currentPath:
            continue            
        # path_split = currentPath.split('.tif_')
        pathNoFilename, filename = os.path.split(currentPath)
        splitHelper = filename.split('_')
        currentBaseImage = splitHelper[0] + '_' + splitHelper[1] + '_' + splitHelper[2]
        if currentBaseImage not in seenBaseImages:
            seenBaseImages.append(currentBaseImage)
            currentTileStartX, currentTileStartY = splitHelper[3], splitHelper[4].split('.')[0]
            currentTileStartX = int(currentTileStartX) - 1 # wtf matlab
            currentTileStartY = int(currentTileStartY) - 1 # wtf matlab
            start_x_indices[currentBaseImage] = []
            start_y_indices[currentBaseImage] = []
            start_x_indices[currentBaseImage].append(currentTileStartX)
            start_y_indices[currentBaseImage].append(currentTileStartY)
        else:
            # decide whether x or y tile
            currentTileStartX, currentTileStartY = splitHelper[3], splitHelper[4].split('.')[0]
            currentTileStartX = int(currentTileStartX) - 1 # wtf matlab
            currentTileStartY = int(currentTileStartY) - 1 # wtf matlab
            start_x_indices[currentBaseImage].append(currentTileStartX)
            start_y_indices[currentBaseImage].append(currentTileStartY)
	
    for currentBaseImage in seenBaseImages:
        max_x = np.max(start_x_indices[currentBaseImage]) + CELL_STEP_X
        max_y = np.max(start_y_indices[currentBaseImage]) + CELL_STEP_Y
        #currentLabelImage = np.zeros((max_x, max_y, 3), dtype=np.uint8)
        currentLabelImage = np.zeros((max_x, max_y), dtype=np.uint8)
        for currentTileIndex in range(len(start_x_indices[currentBaseImage])):
            currentSubImage = np.zeros((SUBIMAGE_WIDTH, SUBIMAGE_HEIGHT))
            for rotation_angle in ROTATION_ANGLES:
                currentSubImage = join_operator(currentSubImage, cv.imread(os.path.join(SLICES_LOCATION, currentBaseImage + '_' +
                                                     str(start_x_indices[currentBaseImage][currentTileIndex]+1) + '_' +
                                                     str(start_y_indices[currentBaseImage][currentTileIndex]+1) + '_rot_' + str(rotation_angle) + '.png'), 0)) # wtf matlab
            #currentSubImage = currentSubImage[:, CELL_STEP_X:, :]
            currentLabelImage[start_x_indices[currentBaseImage][currentTileIndex]:start_x_indices[currentBaseImage][currentTileIndex] + SUBIMAGE_WIDTH,
                      start_y_indices[currentBaseImage][currentTileIndex]:start_y_indices[currentBaseImage][currentTileIndex] + SUBIMAGE_HEIGHT] = join_operator(currentLabelImage[start_x_indices[currentBaseImage][currentTileIndex]:start_x_indices[currentBaseImage][currentTileIndex] + SUBIMAGE_WIDTH,
                      start_y_indices[currentBaseImage][currentTileIndex]:start_y_indices[currentBaseImage][currentTileIndex] + SUBIMAGE_HEIGHT] , currentSubImage)
        cv.imwrite(os.path.join(JOINED_LOCATION, currentBaseImage+'.png'), currentLabelImage)
