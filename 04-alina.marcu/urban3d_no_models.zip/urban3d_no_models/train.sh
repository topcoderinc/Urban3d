#!/usr/bin/env bash
if test "$1" == ""; then
	echo $'\a'Usage: train.sh dataDirTrain dataDirTest
else
cd /topcoder
echo "Preprocessing"
python 1_preprocessing_scripts/split_data_training.py $1

#rm -rf $1
python 1_preprocessing_scripts/extract_water_labels_osm_topcoder_tiff.py /data2/train
ret=$?
while [ $ret -ne 0 ]; do
     #re-extract waters; timeout/ban maybe?
     python 1_preprocessing_scripts/extract_water_labels_osm_topcoder_tiff.py
done
python 1_preprocessing_scripts/norm_dsm_minus_dtm.py preprocessing
python 1_preprocessing_scripts/split_data_water.py /data2/train_water
echo "Slicing for water training"
python 1_preprocessing_scripts/slice_fixed_stride_np.py /data2/train_water 512 # x3 -> RGB, DMD, GTC_water
python 1_preprocessing_scripts/select_water_slices.py /data2/train_water 512
echo "Training water"
python 2_training_scripts/train_water_NN_with_DMD_better_clipping.py /data2/train_water 512 9 
python 4_utils/remove_patches.py /data2/train_water patches_selected_stride_512
python 4_utils/remove_patches.py /data2/train_water patches_stride_512
python 1_preprocessing_scripts/slice_fixed_stride_np.py /data2/train_water 1024 # x3 -> RGB, DMD, GTC_water
echo "Predict water"
python 2_training_scripts/predict_water_with_RGB+DMD_better_clipping.py /data2/train_water training 1024 # only one predict on whole training set
python 2_training_scripts/predict_water_with_RGB+DMD_better_clipping.py /data2/train_water validation 1024

python 3_postprocessing_scripts/join_disjoint_slices.py /data2/train_water/output_patches /data2/train_water/output_joined
# valid threshold
thresh=$(python 3_postprocessing_scripts/get_optimal_threshold_mp.py /data2/train/gtc_water/original /data2/train_water/output_joined 2>&1)  
python 3_postprocessing_scripts/threshold_image_mp.py /data2/train_water/output_joined $thresh /data2/train/gtc_water/original _GTC
echo "Preparing buildings training iteration 1"
python 1_preprocessing_scripts/fix_gtc_uncertain_buildings.py /data2/train
python 1_preprocessing_scripts/norm_dsm_minus_dtm_mask_water.py preprocessing
python 1_preprocessing_scripts/split_data_buildings.py /data2/train_buildings_1 split_buildings_1
python 1_preprocessing_scripts/slice_fixed_stride_np.py /data2/train_buildings_1 512
echo "Training buildings iteration 1"
python 2_training_scripts/train_RGB+DMD_better_clipping_normalized_masked_dataset.py /data2/train_buildings_1 512 21 
# remove old patches
python 4_utils/remove_patches.py /data2/train_buildings_1 patches_stride_512
# concatenate datasets here
# add testing to training
python 1_preprocessing_scripts/split_data_training.py $2 
# generate dmd w/ masked water
python 1_preprocessing_scripts/norm_dsm_minus_dtm.py preprocessing #compute dmd
python 1_preprocessing_scripts/slice_fixed_stride_np_testing.py /data2/train 1024
python 2_training_scripts/predict_water_with_RGB+DMD_better_clipping_testing.py /data2/train 1024 /data2/train_water/checkpoints/net.hdf5
python 3_postprocessing_scripts/join_disjoint_slices.py /data2/train/output_patches_stride_1024_water /data2/train/output_patches_water_joined
python 3_postprocessing_scripts/threshold_image_mp.py /data2/train/output_patches_water_joined $thresh /data2/train/gtc_water/original _GTC 
python 1_preprocessing_scripts/norm_dsm_minus_dtm_mask_water.py preprocessing # generates dmd again + masked rgb
# reslice for predict, full dataset - overwrite patches
python 1_preprocessing_scripts/slice_fixed_stride_np_testing.py /data2/train 1024 # x3 -> RGB, DMD, GTC_water
# we need to predict on the whole dataset
python 2_training_scripts/predict_RGB+DMD_better_clipping_normalized_masked_dataset_training.py /data2/train 1024 /data2/train_buildings_1/checkpoints/net.hdf5
python 3_postprocessing_scripts/join_disjoint_slices.py /data2/train/output_patches /data2/train/output_joined
python 4_utils/remove_patches_testing.py /data2/train patches_stride_1024
thresh_buildings=$(python 3_postprocessing_scripts/get_optimal_threshold_mp.py /data2/train/gtc/original /data2/train/output_joined 2>&1) 
#overwrite gtc
python 3_postprocessing_scripts/threshold_image_mp.py /data2/train/output_joined $thresh_buildings /data2/train/gtc/iteration_1
python 1_preprocessing_scripts/fix_training_labels_add_nn_houses.py /data2/train/gtc/iteration_1
echo "Preparing buildings training iteration 2"
python 1_preprocessing_scripts/split_data_buildings.py /data2/train_buildings_2 split_buildings_2
python 1_preprocessing_scripts/slice_fixed_stride_np.py /data2/train_buildings_2 512 # slice again, won't take long [-> for new GTC corrected GTC only]
echo "Training buildings iteration 2"
python 2_training_scripts/finetune_iteration_1_RGB+DMD_better_clipping_normalized_masked_dataset.py /data2/train_buildings_2  /data2/train_buildings_1 512 12 
echo 'Training done!'
echo 'Copying models to /pretrained_models'
cp /data2/train_water/checkpoints/net.hdf5 pretrained_models/water/water_net.hdf5
cp /data2/train_buildings_1/checkpoints/net.hdf5 pretrained_models/buildings_from_scratch/buildings_net_iteration_0.hdf5
cp /data2/train_buildings_2/checkpoints/net.hdf5 pretrained_models/buildings_iteration_1/buildings_net_iteration_1.hdf5
fi

