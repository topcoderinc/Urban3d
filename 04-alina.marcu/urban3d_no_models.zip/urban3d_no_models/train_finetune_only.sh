#!/usr/bin/env bash
if test "$1" == ""; then
	echo $'\a'Usage: train.sh dataDirTrain dataDirTest
else
cd /topcoder
echo "Preprocessing"
python 1_preprocessing_scripts/split_data_training_gtc_only.py $1
# add testing to training
python 1_preprocessing_scripts/split_data_training_gtc_only.py $2 

thresh_buildings=$(python 3_postprocessing_scripts/get_optimal_threshold_mp.py /data2/train/gtc/original /data2/train/output_joined 2>&1) 
#overwrite gtc
python 3_postprocessing_scripts/threshold_image_mp.py /data2/train/output_joined $thresh_buildings /data2/train/gtc/iteration_1
python 1_preprocessing_scripts/fix_training_labels_add_nn_houses.py /data2/train/gtc/iteration_1
echo "Preparing buildings training iteration 2"
python 1_preprocessing_scripts/split_data_buildings.py /data2/train_buildings_2 split_buildings_2
python 1_preprocessing_scripts/slice_fixed_stride_np.py /data2/train_buildings_2 512 # slice again, won't take long [-> for new GTC corrected GTC only]
echo "Training buildings iteration 2"
python 2_training_scripts/finetune_iteration_1_RGB+DMD_better_clipping_normalized_masked_dataset.py /data2/train_buildings_2  /data2/train_buildings_1 512 12 
echo 'Training done!'
echo 'Copying models to /pretrained_models'
cp /data2/train_water/checkpoints/net.hdf5 pretrained_models/water/water_net.hdf5
cp /data2/train_buildings_1/checkpoints/net.hdf5 pretrained_models/buildings_from_scratch/buildings_net_iteration_0.hdf5
cp /data2/train_buildings_2/checkpoints/net.hdf5 pretrained_models/buildings_iteration_1/buildings_net_iteration_1.hdf5
fi

