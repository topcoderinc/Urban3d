from keras.losses import binary_crossentropy, mean_squared_error
import keras.backend as K
import tensorflow as tf
import numpy as np
#from tensorflow.contrib.framework import sort as tf_sort

def smooth_L1_loss(y_true, y_pred):
    absolute_loss = tf.abs(y_true - y_pred)
    square_loss = 0.5 * (y_true - y_pred) ** 2
    l1_loss = tf.where(tf.less(absolute_loss, 1.0), square_loss, absolute_loss - 0.5)
    return K.sum(l1_loss)

def convert_tensor_to_array(tensor):
    return tensor.eval()
    #return K.eval(tensor)
    
# Softmax log loss
def log_loss(y_true, y_pred):
    # Make sure that 'y_pred' doesn't contain any zeros (which will break the log function)
    y_pred = tf.maximum(y_pred, 1e-15)
    # Compute the log loss
    loss = -tf.reduce_sum(y_true * tf.log(y_pred), axis=1)
    return loss
    
def bootstrapped_xentropy(y_true, y_pred, batch_size=1, multiplier=1):
    #xentropy = -K.sum(y_pred * y_true, axis=1)
    
    xentropy = log_loss(y_true, y_pred)
    
    factor = 512 * multiplier
    
    result = K.constant(0, dtype="float32")

    for i in range(batch_size):
        batch_errors = xentropy[i]
        flat_errors = K.flatten(batch_errors)
        
        worst_errors = tf_sort(flat_errors, direction='ASCENDING')
        
        
        worst_errors = worst_errors[-factor:]

        result += K.mean(worst_errors)
        
    result /= K.constant(batch_size, dtype="float32")
        
    
    return result #+ binary_crossentropy(y_true, y_pred) + l2_loss(y_true, y_pred)

def l2_loss(y_true, y_pred):
    loss = mean_squared_error(y_true, y_pred)
    return loss
    
def bce_l2_loss(y_true, y_pred):
    loss = binary_crossentropy(y_true, y_pred) + l2_loss(y_true, y_pred)
    return loss

def dice_coeff(y_true, y_pred):
    smooth = 1.
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    intersection = K.sum(y_true_f * y_pred_f)
    score = (2. * intersection + smooth) / (K.sum(y_true_f) + K.sum(y_pred_f) + smooth)
    return score


def dice_loss(y_true, y_pred):
    loss = 1 - dice_coeff(y_true, y_pred)
    return loss


def bce_dice_loss(y_true, y_pred):
    loss = binary_crossentropy(y_true, y_pred) + dice_loss(y_true, y_pred)
    return loss


def weighted_dice_coeff(y_true, y_pred, weight):
    smooth = 1.
    w, m1, m2 = weight * weight, y_true, y_pred
    intersection = (m1 * m2)
    score = (2. * K.sum(w * intersection) + smooth) / (K.sum(w * m1) + K.sum(w * m2) + smooth)
    return score
