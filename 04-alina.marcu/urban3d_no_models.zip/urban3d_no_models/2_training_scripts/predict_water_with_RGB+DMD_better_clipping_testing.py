import cv2
import numpy as np
import pandas as pd
import os
import sys

from nn.models import get_unet_MDCB_even_more_filters

import yaml 

SETTINGS_FILENAME = 'settings.yaml'

with open(SETTINGS_FILENAME, 'r') as f:
    settings = yaml.load(f)

DATASET_NAME = sys.argv[1]

STRIDE = int(sys.argv[2])

WATER_CHECKPOINT_PATH = sys.argv[3]

input_size = 1024
batch_size = 1
orig_width = 1024
orig_height = 1024

model = get_unet_MDCB_even_more_filters(input_shape=(1024,1024,4))

RGB_PATH = os.path.join(DATASET_NAME, 'rgb/patches_stride_' +str(STRIDE))
DSM_PATH = os.path.join(DATASET_NAME, 'dmd/patches_stride_' +str(STRIDE))

test_path = RGB_PATH
ids_test = []
test_files = os.listdir(test_path)
for filename in test_files:
    ids_test.append(os.path.basename(filename))

model.load_weights(WATER_CHECKPOINT_PATH)


output_dir = os.path.join(DATASET_NAME, 'output_patches_stride_'+str(STRIDE)+'_water')
if not os.path.isdir(output_dir):
    os.makedirs(output_dir)

print('Predicting on {} samples with batch_size = {}...'.format(len(ids_test), batch_size))
for start in range(0, len(ids_test), batch_size):
    x_batch = []
    end = min(start + batch_size, len(ids_test))
    ids_test_batch = ids_test[start:end]
    for id in ids_test_batch:
        img = cv2.imread(os.path.join(test_path, '{}').format(id))
        img = cv2.resize(img, (input_size, input_size))
        
        id_splits = id.split('.')[0].split('_')
        dmd_name = "{0}_{1}_{2}_DMD_{3}_{4}.npy".format(id_splits[0], id_splits[1], id_splits[2], id_splits[4], id_splits[5])
        dsm_minus_dtm = np.load(DSM_PATH + '/{}'.format(dmd_name))
        dsm_minus_dtm *= 255.
        
        img = np.stack((img[:,:,0], img[:,:,1], img[:,:,2], dsm_minus_dtm), axis=-1)
        
        x_batch.append(img)
    x_batch = np.array(x_batch, np.float32) / 255
    preds = model.predict_on_batch(x_batch)
    preds = np.squeeze(preds, axis=3)
    print('Predicting water on {0}/{1}'.format(start, len(ids_test)))
    for idx, pred in enumerate(preds):
        prob = cv2.resize(pred, (orig_width, orig_height))
        mask = prob
        mask *= 255
        cv2.imwrite(os.path.join(output_dir, ids_test_batch[idx].replace('_RGB', '').replace('.tif', '.png')), mask)

