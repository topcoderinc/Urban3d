import cv2
import numpy as np
import pandas as pd
#from tqdm import tqdm

import os
import sys
from nn.models import get_unet_MDCB_even_more_filters

DATASET_NAME = sys.argv[1]

DATASET_TYPE = sys.argv[2]

STRIDE = 1024

input_size = 1024
batch_size = 1
orig_width = 1024
orig_height = 1024

model = get_unet_MDCB_even_more_filters(input_shape=(1024,1024,4))

RGB_PATH = os.path.join(DATASET_NAME, DATASET_TYPE, 'rgb/patches') # '/nvme-nets/misc/topcoder/data/dataset_20171203_corrected/TEST_62/RGB_masked_water_20171201/disjoint_slices_1024'
DMD_PATH = os.path.join(DATASET_NAME, DATASET_TYPE, 'dmd/patches') # '/nvme-nets/misc/topcoder/data/dataset_20171203_corrected/TEST_62/norm_DMD_better_clipping_masked_waters_20171201/disjoint_slices_1024'

test_path = RGB_PATH
ids_test = []
test_files = os.listdir(test_path)
for filename in test_files:
    ids_test.append(os.path.basename(filename))
    
if len(sys.argv) > 3:
    model.load_weights(sys.argv[3])
else:
    model.load_weights(filepath=os.path.join(DATASET_NAME, 'checkpoints/net.hdf5'))


output_dir = os.path.join(DATASET_NAME, 'output_patches')

if not os.path.isdir(output_dir):
    os.makedirs(output_dir)

print('Predicting on {} samples with batch_size = {}...'.format(len(ids_test), batch_size))
for start in range(0, len(ids_test), batch_size):
    x_batch = []
    end = min(start + batch_size, len(ids_test))
    ids_test_batch = ids_test[start:end]
    for id in ids_test_batch:
        # RGB
        img = cv2.imread(RGB_PATH + '/{}'.format(id))
        img = cv2.resize(img, (input_size, input_size))
        id_splits = id.split('.')[0].split('_')
        # DSM
        dmd_name = "{0}_{1}_{2}_DMD_{3}_{4}.npy".format(id_splits[0], id_splits[1], id_splits[2], id_splits[4], id_splits[5])
        dmd = np.load(DMD_PATH + '/{}'.format(dmd_name))
        dmd *= 255.
        
        img = np.stack((img[:,:,0], img[:,:,1], img[:,:,2], dmd), axis=-1)
        
        x_batch.append(img)
    x_batch = np.array(x_batch, np.float32) / 255
    preds = model.predict_on_batch(x_batch)
    preds = np.squeeze(preds, axis=3)
    print('Predicting buildings on {0}/{1}'.format(start, len(ids_test)))
    for idx, pred in enumerate(preds):
        prob = cv2.resize(pred, (orig_width, orig_height))
        mask = prob #> threshold
        mask *=255
        #print(np.count_nonzero(mask == 255))
        #print(np.min(mask))
        #print(np.mean(mask))
        #print(np.max(mask))
        #print(np.max(np.max(mask)))
        #print(os.path.join(output_dir, ids_test_batch[idx]))
        #hello
        cv2.imwrite(os.path.join(output_dir, ids_test_batch[idx].replace('_RGB', '').replace('.tif', '.png')), mask)


