#!/usr/bin/env bash
if test "$1" == ""; then
    echo $'\a'Usage: test.sh /data/train /data/test out_filename
    echo $'\a'out_filename will be saved at /data/out_filename
else

# predict on another dataset
echo "test_dir":$2
python 1_preprocessing_scripts/split_data_testing.py $2
python 1_preprocessing_scripts/norm_dsm_minus_dtm.py testing # compute dmd
python 1_preprocessing_scripts/slice_fixed_stride_np_testing.py /data2/test 1024
python 2_training_scripts/predict_water_with_RGB+DMD_better_clipping_testing.py /data2/test 1024 pretrained_models/water/water_net.hdf5
python 3_postprocessing_scripts/join_disjoint_slices.py /data2/test/output_patches_stride_1024_water /data2/test/output_patches_water_joined
python 3_postprocessing_scripts/threshold_image_mp.py /data2/test/output_patches_water_joined 0.89 /data2/test/gtc_water/original _GTC
python 1_preprocessing_scripts/norm_dsm_minus_dtm_mask_water.py testing # generates dmd again + masked rgb
python 1_preprocessing_scripts/slice_fixed_stride_np_testing.py /data2/test 1024
python 2_training_scripts/predict_iteration_1_RGB+DMD_better_clipping_normalized_masked_dataset_testing.py /data2/test 1024 pretrained_models/buildings_iteration_1/buildings_net_iteration_1.hdf5
python 3_postprocessing_scripts/join_disjoint_slices.py /data2/test/output_patches /data2/test/output_patches_joined
python 3_postprocessing_scripts/threshold_image_mp.py /data2/test/output_patches_joined 0.5 /data2/test/output_thresholded
python 3_postprocessing_scripts/make_rle_fill_holes_remove_spurr_pixels_aio.py /data2/test/output_thresholded $3
rm -rf /data2/test
fi
