import os
import cv2 as cv
import numpy as np
from PIL import Image
import skimage
#import scipy.ndimage. as binary_dilation
import scipy.ndimage as ndimage
import glob

DSM_LOCATION_1 ='/nvme-nets/misc/topcoder/data/dataset_20171128/TEST_62/DSM/original'
DTM_LOCATION_1 ='/nvme-nets/misc/topcoder/data/dataset_20171128/TEST_62/DTM/original'

#DSM_LOCATION_2 ='/nvme-nets/misc/topcoder/data/dataset_20171128/VALID_24/DSM'
#DTM_LOCATION_2 ='/nvme-nets/misc/topcoder/data/dataset_20171128/VALID_24/DTM'

"""

DSM
global_min -52.0792
global_max 160.119

DTM
global_min -46.0278
global_max 8.28125


"""


DSM_NO_VALUE = -32000


paths_1 = glob.glob(DSM_LOCATION_1 + '/*.*')
#paths_2 = glob.glob(DTM_LOCATION_2 + '/*.*')

paths = paths_1 #+ paths_2

         
global_min = 1000
global_max = -1000
for current_image_path in paths:
    #current_image = cv.imread(current_image_path)
    current_image_PIL = Image.open(current_image_path)
    current_image = np.array(current_image_PIL)
    current_image[np.less(current_image, DSM_NO_VALUE)] = 0
    global_min = min(global_min, np.min(np.min(current_image)))
    global_max = max(global_max, np.max(np.max(current_image)))

print('global_min', global_min)
print('global_max', global_max)
