import os
import shutil
import sys
#settings
import yaml

SETTINGS_FILENAME = 'settings.yaml'

with open(SETTINGS_FILENAME, 'r') as f:
    settings = yaml.load(f)

DATASET_NAME = sys.argv[1]

DMD_LOCATION = settings['preprocessing']['norm']['DMD_LOCATION']
RGB_LOCATION = settings['preprocessing']['norm']['RGB_LOCATION']
GTC_WATER_LOCATION = settings['preprocessing']['norm']['GTC_WATER_LOCATION']

TRAIN_FILELIST = settings['preprocessing']['split_water']['TRAINING']
VALIDATION_FILELIST = settings['preprocessing']['split_water']['VALIDATION']

DMD_TRAINING_ORIGINAL = os.path.join(DATASET_NAME, 'training/dmd/original')
RGB_TRAINING_ORIGINAL = os.path.join(DATASET_NAME, 'training/rgb/original')
GTC_WATER_TRAINING_ORIGINAL = os.path.join(DATASET_NAME, 'training/gtc/original')
DMD_VALIDATION_ORIGINAL = os.path.join(DATASET_NAME, 'validation/dmd/original')
RGB_VALIDATION_ORIGINAL = os.path.join(DATASET_NAME , 'validation/rgb/original')
GTC_WATER_VALIDATION_ORIGINAL = os.path.join(DATASET_NAME, 'validation/gtc/original')

if not os.path.exists(DMD_TRAINING_ORIGINAL):
    os.makedirs(DMD_TRAINING_ORIGINAL)

if not os.path.exists(RGB_TRAINING_ORIGINAL):
    os.makedirs(RGB_TRAINING_ORIGINAL)
    
if not os.path.exists(GTC_WATER_TRAINING_ORIGINAL):
    os.makedirs(GTC_WATER_TRAINING_ORIGINAL)
    
if not os.path.exists(DMD_VALIDATION_ORIGINAL):
    os.makedirs(DMD_VALIDATION_ORIGINAL)   

if not os.path.exists(RGB_VALIDATION_ORIGINAL):
    os.makedirs(RGB_VALIDATION_ORIGINAL) 
    
if not os.path.exists(GTC_WATER_VALIDATION_ORIGINAL):
    os.makedirs(GTC_WATER_VALIDATION_ORIGINAL)


for current_file in open(TRAIN_FILELIST).readlines():
    current_file = current_file.rstrip()
    current_basename = os.path.basename(current_file)
    name_no_extension = current_basename.split('.')[0]
    
    shutil.copy2(os.path.join(RGB_LOCATION, current_file), os.path.join(RGB_TRAINING_ORIGINAL, current_file))
    shutil.copy2(os.path.join(DMD_LOCATION, current_file.replace('_RGB.tif', '_DMD.npy')), os.path.join(DMD_TRAINING_ORIGINAL, current_file.replace('_RGB.tif', '_DMD.npy')))        
    shutil.copy2(os.path.join(GTC_WATER_LOCATION,  current_basename.replace('_RGB.tif', '_GTC.png')), os.path.join(GTC_WATER_TRAINING_ORIGINAL, current_basename.replace('_RGB.tif', '_GTC.png')))  
    
for current_file in open(VALIDATION_FILELIST).readlines():
    current_file = current_file.rstrip()
    current_basename = os.path.basename(current_file)
    name_no_extension = current_basename.split('.')[0]
    
    shutil.copy2(os.path.join(RGB_LOCATION, current_file), os.path.join(RGB_VALIDATION_ORIGINAL, current_file))
    shutil.copy2(os.path.join(DMD_LOCATION, current_file.replace('_RGB.tif', '_DMD.npy')), os.path.join(DMD_VALIDATION_ORIGINAL, current_file.replace('_RGB.tif', '_DMD.npy')))       
    shutil.copy2(os.path.join(GTC_WATER_LOCATION,  current_basename.replace('_RGB.tif', '_GTC.png')), os.path.join(GTC_WATER_VALIDATION_ORIGINAL, current_basename.replace('_RGB.tif', '_GTC.png')))   
    
