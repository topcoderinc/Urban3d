import os
import glob
import cv2 as cv
import numpy as np
import yaml 
import shutil

SETTINGS_FILENAME = 'settings.yaml'

with open(SETTINGS_FILENAME, 'r') as f:
    settings = yaml.load(f)

import sys 



GTC_SOURCE_FOLDER = os.path.join(sys.argv[1], 'gtc/original')

"""
main_path = '/home/gogu/Downloads/misc/topcoder/test_convert_labels'
dataset_type = 'training'

output_dir = os.path.join(main_path,'dataset', dataset_type);
if not os.path.exists(output_dir):
    os.makedirs(output_dir)
"""

filenames = glob.glob(GTC_SOURCE_FOLDER+"/*.tif")


for current_file in filenames:
    
    name_no_extension = os.path.basename(current_file).split('.')[0]
    if not 'GTC' in current_file:
        continue
    current_image = cv.imread(current_file)
    print(current_image.shape)
    current_image_out = np.zeros_like(current_image)
    current_image_out[current_image == (0, 140, 220)] = 255
    current_image_out[current_image == (96, 96, 96)] = 255
    cv.imwrite(os.path.join(output_dir, name_no_extension+'.png'), current_image_out)
    os.remove(current_file)
