#!/usr/bin/env python
# -*- coding: utf-8 -*-

import shutil
import os
import glob
import numpy as np
import cv2 as cv
import json
import argparse
import h5py
import scipy.misc
import math
from PIL import Image
import sys 

INPUT_FOLDER = sys.argv[1]

STRIDE = str(sys.argv[2])
    
def select_water_slices (dataset_type):

    rgb_path = os.path.join(INPUT_FOLDER, dataset_type, 'rgb/patches_stride_'+STRIDE)
    rgb_path_out = os.path.join(INPUT_FOLDER, dataset_type, 'rgb/patches_selected_stride_'+STRIDE)
    if os.path.exists(rgb_path_out):
        shutil.rmtree(rgb_path_out)
    os.makedirs(rgb_path_out)
    
    gtc_path = os.path.join(INPUT_FOLDER, dataset_type, 'gtc/patches_stride_'+STRIDE)
    gtc_path_out = os.path.join(INPUT_FOLDER, dataset_type, 'gtc/patches_selected_stride_'+STRIDE)
    if os.path.exists(gtc_path_out):
        shutil.rmtree(gtc_path_out)
    os.makedirs(gtc_path_out)
    
    dsm_path = os.path.join(INPUT_FOLDER, dataset_type, 'dmd/patches_stride_'+STRIDE)
    dsm_path_out = os.path.join(INPUT_FOLDER, dataset_type, 'dmd/patches_selected_stride_'+STRIDE)
    if os.path.exists(dsm_path_out):
        shutil.rmtree(dsm_path_out)
    os.makedirs(dsm_path_out)

    # get filenames
    rgb_input_fns = np.asarray(sorted(glob.glob('%s/*%s' % (rgb_path, '.tif'))))
    gtc_input_fns = np.asarray(sorted(glob.glob('%s/*%s' % (gtc_path, '.png'))))
    dsm_input_fns = np.asarray(sorted(glob.glob('%s/*%s' % (dsm_path, '.npy'))))

    n_all_files = len(rgb_input_fns)
    print('n_all_files:', n_all_files, len(gtc_input_fns), len(dsm_input_fns))

    n_patches = 0
    for rgb_name, gtc_name, dsm_name in zip(rgb_input_fns, gtc_input_fns, dsm_input_fns):

        rgb_im_name = os.path.basename(rgb_name)
        gtc_im_name = os.path.basename(gtc_name)
        dsm_im_name = os.path.basename(dsm_name) 
        
        current_image_PIL = Image.open(rgb_path + '/' + rgb_im_name)
        rgb_im = np.array(current_image_PIL)
        
        current_image_PIL = Image.open(gtc_path + '/' + gtc_im_name).convert('L')
        gtc_img = np.array(current_image_PIL)  
        
        dsm_img = np.load(dsm_path + '/' + dsm_im_name)

        if np.max(np.max(gtc_img)) != 0:
            cv.imwrite(os.path.join(rgb_path_out, rgb_im_name), rgb_im)
            cv.imwrite(os.path.join(gtc_path_out, gtc_im_name), gtc_img)
            np.save(os.path.join(dsm_path_out, dsm_im_name), dsm_img)
                
if __name__ == '__main__':
    select_water_slices('training')
    select_water_slices('validation')                                   
                                               
