import os
import shutil
import glob
#settings
import yaml
import sys

SETTINGS_FILENAME = 'settings.yaml'

with open(SETTINGS_FILENAME, 'r') as f:
    settings = yaml.load(f)

DATA_LOCATION_IN = sys.argv[1]

DSM_LOCATION = settings['testing']['norm']['DSM_LOCATION']
DTM_LOCATION = settings['testing']['norm']['DTM_LOCATION']
RGB_LOCATION = settings['testing']['norm']['RGB_LOCATION']

filenames = glob.glob(DATA_LOCATION_IN+"/*.tif")

if not os.path.exists(DSM_LOCATION):
    os.makedirs(DSM_LOCATION)

if not os.path.exists(DTM_LOCATION):
    os.makedirs(DTM_LOCATION)
    
if not os.path.exists(RGB_LOCATION):
    os.makedirs(RGB_LOCATION)   



for current_file in filenames:
    current_basename = os.path.basename(current_file)
    name_no_extension = current_basename.split('.')[0]
    if 'RGB' in current_file:
        shutil.copy2(current_file, os.path.join(RGB_LOCATION, current_basename))
    elif 'DTM' in current_file:
        shutil.copy2(current_file, os.path.join(DTM_LOCATION, current_basename))       
    elif 'DSM' in current_file:
        shutil.copy2(current_file, os.path.join(DSM_LOCATION, current_basename))         
