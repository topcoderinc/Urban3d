import os
import shutil
import glob
import cv2 as cv
import numpy as np
import sys
#settings
import yaml

SETTINGS_FILENAME = 'settings.yaml'

with open(SETTINGS_FILENAME, 'r') as f:
    settings = yaml.load(f)

DATA_LOCATION_IN = sys.argv[1]

DSM_LOCATION = settings['preprocessing']['norm']['DSM_LOCATION']
DTM_LOCATION = settings['preprocessing']['norm']['DTM_LOCATION']
RGB_LOCATION = settings['preprocessing']['norm']['RGB_LOCATION']
GTC_LOCATION = settings['preprocessing']['norm']['GTC_LOCATION']
GTI_LOCATION = settings['preprocessing']['norm']['GTI_LOCATION']

filenames = glob.glob(DATA_LOCATION_IN+"/*.tif")

if not os.path.exists(DSM_LOCATION):
    os.makedirs(DSM_LOCATION)

if not os.path.exists(DTM_LOCATION):
    os.makedirs(DTM_LOCATION)
    
if not os.path.exists(RGB_LOCATION):
    os.makedirs(RGB_LOCATION)   

if not os.path.exists(GTC_LOCATION):
    os.makedirs(GTC_LOCATION) 

if not os.path.exists(GTI_LOCATION):
    os.makedirs(GTI_LOCATION) 

for current_file in filenames:
    current_basename = os.path.basename(current_file)
    name_no_extension = current_basename.split('.')[0]
    if 'GTC' in current_file:
        current_image = cv.imread(current_file)
        current_image_out = np.zeros_like(current_image)
        current_image_out[current_image == (0, 140, 220)] = 255
        current_image_out[current_image == (96, 96, 96)] = 255
        cv.imwrite(os.path.join(GTC_LOCATION, name_no_extension+'.png'), current_image_out)
    elif 'RGB' in current_file:
        shutil.copy2(current_file, os.path.join(RGB_LOCATION, current_basename))
    elif 'DTM' in current_file:
        shutil.copy2(current_file, os.path.join(DTM_LOCATION, current_basename))       
    elif 'DSM' in current_file:
        shutil.copy2(current_file, os.path.join(DSM_LOCATION, current_basename))       
    elif 'GTI' in current_file:
        shutil.copy2(current_file, os.path.join(GTI_LOCATION, current_basename))    
