"""
required packages:
numpy
matplotlib
basemap: http://matplotlib.org/basemap/users/installing.html
shapely: https://pypi.python.org/pypi/Shapely
descartes: https://pypi.python.org/pypi/descartes
random


numpy and random are only required to generate random points for this example

"""
# fixes
from __future__ import print_function

# draw ground truth
# from random import shuffle, randint, random
import random
import numpy as np
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from matplotlib.collections import PatchCollection
from mpl_toolkits.basemap import Basemap
from shapely.geometry import Point, MultiPoint, MultiPolygon, LineString
from shapely.geometry import Polygon as ShapelyPolygon
from shapely.geometry import box as ShapelyBox
from shapely.ops import transform as ShapelyTransform
from descartes import PolygonPatch
import overpy
import math
#import Image
# download map
import re
import time
import gc
import sys
import multiprocessing as mp
# load config and data stuff
import csv
# edit html file for google
import fileinput
import re
# delete useless images
import os
# local osm command line utyilities
import pexpect
# multiprocess
import multiprocessing as mp
# for random string string
import string
# list dir
import glob
# read geotiff
from osgeo import osr, gdal

import geopandas as gp
#download water polygons
import urllib
#unzip 
import zipfile
#settings
import yaml

SETTINGS_FILENAME = 'settings.yaml'

with open(SETTINGS_FILENAME, 'r') as f:
    settings = yaml.load(f)

#get training data location
DATA_LOCATION = sys.argv[1]


#download water polygons
OSM_WATER_POLYGONS = settings['preprocessing']['OSM_WATER_POLYGONS']
print('Downloading water polygons shapefile')
if not os.path.exists(os.path.join(DATA_LOCATION, 'water_polygons')):
    os.makedirs(os.path.join(DATA_LOCATION, 'water_polygons'))

OUT_WATER_ZIP_NAME = os.path.join(DATA_LOCATION, 'water_polygons', settings['preprocessing']['WATER_ZIP_NAME'])
if not os.path.isfile(OUT_WATER_ZIP_NAME):
    urllib.urlretrieve(OSM_WATER_POLYGONS, filename=OUT_WATER_ZIP_NAME)

    waters_archive = zipfile.ZipFile(OUT_WATER_ZIP_NAME)
    waters_archive.extractall(os.path.join(DATA_LOCATION, 'water_polygons', 'water-polygons-split-4326'))

water_polygons = gp.GeoDataFrame.from_file(os.path.join(DATA_LOCATION, 'water_polygons', 'water-polygons-split-4326', 'water-polygons-split-4326', 'water_polygons.shp'))
print('\nLOADED WATER POLYS\n')

# PARAMS


MAX_DISTANCE_BETWEEN_POINTS_KML = 20 # meters

SAVED_FEATURE_IDS = ['7','8','12','13']  # 16 houses 15 int, 14 roads, 7,8,12 water

SAVED_INTERSECTION_SIZE = 13

DESTINATION_FOLDER_NAME = []

RESULT_COLOR = '#ffffff'

RESULT_TYPE = 'line'

mapProviders = ('gmaps', 'bmaps')

ZOOM_LEVEL = 17
SHOW_CONTROL_POINTS = False

SAVE_MAP = False

SAVE_XML = False

# HOUSES PARAMS
MIN_LAT = 36
MIN_LON = -9
MAX_LAT = 71
MAX_LON = 66
NUMBER_OF_BUILDINGS_THRESHOLD = 40
BULDINGS_AREA_THESHOLD = 300
BUILDINGS_PERCENT_THRESHOLD = 0.2

AVERAGE_DISTANCE_BELOW = 30  # meters!

# LOCAL OSM
LOCAL_OSM_LOCATION = '/media/gogu/osm/overpass/osm-3s-dev-version/build/bin/osm3s_query --db-dir=/media/gogu/osm/overpass/osm-3s-dev-version/build/db'

# PARAMS_2, do not change unless you know what you're doing

MERCATOR_OFFSET = 268435456
MERCATOR_RADIUS = 85445659.44705395

SATMAP_WIDTH = 2000
SATMAP_HEIGHT = 2000


CONFIG_FILENAME = 'config_topcoder_osm.txt'




def generatePatchesLocalOSM(api, queryId, query, queryType, resultType, resultColor, minx, miny, maxx, maxy, ax, m,interestPointLon,interestPointLat,ZOOM_LEVEL):
    if queryType == 'intersection':
        queryString="""
    <query type="way" into="hw">
      <has-kv k="highway"/>
      <has-kv k="highway" modv="not" regv="footway|cycleway|path|track"/>
       <bbox-query w= \""""+str(minx)+"""\" n=\""""+str(maxy)+"""\" s=\""""+str(miny)+"""\" e=\""""+str(maxx)+"""\"/>
    </query>

    <foreach from="hw" into="w">
      <recurse from="w" type="way-node" into="ns"/>
      <recurse from="ns" type="node-way" into="w2"/>
      <query type="way" into="w2">
        <item set="w2"/>
        <has-kv k="highway"/>
        <has-kv k="highway" modv="not" regv="footway|cycleway|path|service|track"/>
      </query>
      <difference into="wd">
        <item set="w2"/>
        <item set="w"/>
      </difference>
      <recurse from="wd" type="way-node" into="n2"/>
      <recurse from="w"  type="way-node" into="n3"/>
      <query type="node">
        <item set="n2"/>
        <item set="n3"/>
      </query>
      <print/>
    </foreach>
        """
        print( "plotting" + queryString)
        result = runOnlineQuery(api, queryString)
        if SAVE_XML:
            with open("{0:0.7f}_{1:0.7f}_{2}_{3}.xml".format(interestPointLon,interestPointLat,ZOOM_LEVEL, queryId), 'w') as fail:
                fail.write(resultXML)
        numberOfNodesMinusOne=len(result.nodes)-1
        for idx,node in enumerate(result.nodes): # foreach road
            if idx == numberOfNodesMinusOne: break
            print( str(node.lon) + " lat: " + str(node.lat))
                #lonm, latm = m(float(node.lon), float(node.lat))
            ax.add_patch(PolygonPatch(Point(m(float(node.lon),float(node.lat))).buffer(20), fc=resultColor, ec=resultColor, alpha=1, zorder=1))
            ax.add_patch(PolygonPatch(Point(m(float(node.lon),float(node.lat))).buffer(0.7), fc='#13f0ec', ec=resultColor, alpha=1, zorder=1))
            
    else:
        queryString=str(queryType)+"""("""+str(miny)+""","""+str(minx)+""","""+str(maxy)+""","""+str(maxx)+""") ["""+str(query)+"""];
        (._;>;);
        out body;
        """
        #print( "plotting " + query)
        
        results = runOnlineQuery(api, queryString)
        # save response for later use
        if SAVE_XML:
            with open("{0:0.7f}_{1:0.7f}_{2}_{3}.xml".format(interestPointLon,interestPointLat,ZOOM_LEVEL, queryId), 'w') as fail:
                fail.write(resultXML)
        if queryType == 'relation':
            if len(results.relations) == 0:
                return
            else:
                print('num relations:', len(results.relations), 'num nodes:', len(results.nodes))
            num_relations = len(results.relations)
            for relation in results.relations:
                # save first way
                latlon=[]
                lat_c = []
                lon_c = []
                way_0 = relation.members[0].resolve()
                for node in way_0.nodes:
                    lonm, latm = m(float(node.lon), float(node.lat))
                    latlon.append((lonm, latm))
                    lat_c.append(float(node.lat))
                    lon_c.append(float(node.lon)) 
                current_endpoint = way_0.nodes[-1].id
                
                # loop through remaining ways
                num_ways = len(relation.members)
                remaining_ways = range(1, num_ways)
                while len(remaining_ways) > 0:# not empty
                    found = False
                    wayIdxs = range(len(remaining_ways))
                    for rIdx in wayIdxs:
                        way = relation.members[remaining_ways[rIdx]].resolve()
                        if current_endpoint == way.nodes[0].id:
                            for node in way.nodes:
                                lonm, latm = m(float(node.lon), float(node.lat))
                                latlon.append((lonm, latm))
                                lat_c.append(float(node.lat))
                                lon_c.append(float(node.lon))
                            current_endpoint = way.nodes[-1].id
                            remaining_ways.pop(rIdx)# remaining
                            found = True
                            break
                        elif current_endpoint == way.nodes[-1].id:
                            for node in way.nodes[::-1]:
                                lonm, latm = m(float(node.lon), float(node.lat))
                                latlon.append((lonm, latm))
                                lat_c.append(float(node.lat))
                                lon_c.append(float(node.lon))
                            current_endpoint = way.nodes[0].id
                            remaining_ways.pop(rIdx)# remaining
                            found = True
                            break
                    if not found:
                        break
                # plot
                poly=ShapelyPolygon(latlon).buffer(0.1)
                if type(poly) is MultiPolygon:
                    for polygon in poly:
                        patch=PolygonPatch(polygon, fc=resultColor, ec=resultColor, alpha=1, zorder=1)
                        ax.add_patch(patch)
                else:
                    patch=PolygonPatch(poly, fc=resultColor, ec=resultColor, alpha=1, zorder=1)
                    ax.add_patch(patch)
        else:
            for way in results.ways: # foreach road
                latlon=[]
                lat_c = []
                lon_c = []

                for node in way.nodes:
                    lonm, latm = m(float(node.lon), float(node.lat))
                    latlon.append((lonm, latm))
                    lat_c.append(float(node.lat))
                    lon_c.append(float(node.lon))
                    
                if resultType == "poly":
                    if len(latlon) > 2:
                        poly=ShapelyPolygon(latlon).buffer(0.1)
                        if type(poly) is MultiPolygon:
                            for polygon in poly:
                                patch=PolygonPatch(polygon, fc=resultColor, ec=resultColor, alpha=1, zorder=1)
                                ax.add_patch(patch)
                        else:
                            patch=PolygonPatch(poly, fc=resultColor, ec=resultColor, alpha=1, zorder=1)
                            ax.add_patch(patch)
                elif resultType == "line":
                    if len(latlon) > 1:
                        poly=LineString(latlon).buffer(4)
                        patch=PolygonPatch(poly, fc=resultColor, ec=resultColor, alpha=1, zorder=1)
                        ax.add_patch(patch)


def runLocalQuery(queryString):
    c = pexpect.spawn(LOCAL_OSM_LOCATION)
    c.sendline(queryString)
    c.sendcontrol('d')
    c.expect('</osm>', timeout=120)
    # return c.before + '</osm>'
    resultingXML = c.before.rpartition('<?xml')[-1]
    return '<?xml' + resultingXML + '</osm>'
    
def runOnlineQuery(api, queryString):
    return api.query(queryString)



def main(currentImageName):
    if os.path.isfile(os.path.join(DESTINATION_FOLDER_NAME, currentImageName.replace('_GTI.tif', '_GTC.png'))):
        return
    
    # initialize overpy
    api = overpy.Overpass()

    # open coords file, read lat/lon pairs
    configFile = open(CONFIG_FILENAME, 'rb')
    configReader = csv.reader(configFile, delimiter=",", quotechar='@')
    # for i in range(200):

    print("processing {0}".format(currentImageName))

    interestPointLat = 1.23
    interestPointLon = 4.56
    
    ds = gdal.Open(currentImageName)

    # get the existing coordinate system
    old_cs= osr.SpatialReference()
    old_cs.ImportFromWkt(ds.GetProjectionRef())

    # create the new coordinate system
    wgs84_wkt = """
    GEOGCS["WGS 84",
        DATUM["WGS_1984",
            SPHEROID["WGS 84",6378137,298.257223563,
                AUTHORITY["EPSG","7030"]],
            AUTHORITY["EPSG","6326"]],
        PRIMEM["Greenwich",0,
            AUTHORITY["EPSG","8901"]],
        UNIT["degree",0.01745329251994328,
            AUTHORITY["EPSG","9122"]],
        AUTHORITY["EPSG","4326"]]"""
    new_cs = osr.SpatialReference()
    new_cs .ImportFromWkt(wgs84_wkt)

    # create a transform object to convert between coordinate systems
    transform = osr.CoordinateTransformation(old_cs,new_cs) 

    #get the point to transform, pixel (0,0) in this case
    width = ds.RasterXSize
    height = ds.RasterYSize
    gt = ds.GetGeoTransform()
    minx = gt[0]
    miny = gt[3] + width*gt[4] + height*gt[5] 
    maxx = gt[0] + width*gt[1] + height*gt[2]
    maxy = gt[3]
     
    minx, miny, _ = transform.TransformPoint(minx, miny)
    maxx, maxy, _ = transform.TransformPoint(maxx, maxy)

    #print('Limitys lat lon', minx, miny, maxx, maxy)

    # create a new matplotlib figure and axes instance
    fig = plt.figure(frameon=False)
    DPI = fig.get_dpi()
    fig = plt.figure(figsize=(2048, 2048), dpi=1, frameon=False)
    ax = plt.Axes(fig, [0., 0., 1., 1.])
    ax.set_axis_off()
    fig.add_axes(ax)
    m = Basemap(
        projection='merc',
        ellps='WGS84',
        width=20,
        height=20,
        llcrnrlon=minx,
        llcrnrlat=miny,
        urcrnrlon=maxx,
        urcrnrlat=maxy,
        resolution='h',  # h
        suppress_ticks=True)  # width and height in meters

    studyarea = ShapelyBox(minx, miny, maxx,maxy)
    current_water_polygons = water_polygons[water_polygons.geometry.intersects(studyarea)]
    print(current_water_polygons)
    patches = []
    for poly in current_water_polygons.geometry:
        if poly.geom_type == 'Polygon':
            mpoly = ShapelyTransform(m, poly)
            ax.add_patch(PolygonPatch(mpoly, fc='#ffffff', ec='#ffffff', alpha=1, zorder=1 ))
        elif poly.geom_type == 'MultiPolygon':
            for subpoly in poly:
                mpoly = ShapelyTransform(m, poly)
                ax.add_patch(PolygonPatch(mpoly, fc='#ffffff', ec='#ffffff', alpha=1, zorder=1))

    min_x, min_y = m(minx, miny)

    max_x, max_y = m(maxx, maxy)

    #print('Limits', min_x, min_y, max_x, max_y)
    corr_w, corr_h = max_x - min_x, max_y - min_y

    ax.set_xlim(min_x, max_x)
    ax.set_ylim(min_y, max_y)

    if not os.path.exists(DESTINATION_FOLDER_NAME):
        os.makedirs(DESTINATION_FOLDER_NAME)

    configFile.seek(0)
    for row in reversed(list(configReader)):
        if row[0] in SAVED_FEATURE_IDS:
            queryId = row[0]
            queryType = row[1]
            query = row[2]
            resultType = row[3]
            resultColor = row[4]
            generatePatchesLocalOSM(api, queryId, query, queryType, resultType, resultColor, minx,
                                                         miny, maxx, maxy, ax, m, interestPointLon, interestPointLat,
                                                         ZOOM_LEVEL)

    if SHOW_CONTROL_POINTS is True:
        # add "control points": trim when finding them, enlarge the map to fit; assumes LLTBBF works
        # lower left corner (lon:minX, lat:minY)
        ax.add_patch(PolygonPatch(Point(m(minx, miny)).buffer(5), fc='#ffffff', ec='#ffffff', alpha=1, zorder=5))
        # upper left corner (lon:minX, lat:maxY)
        ax.add_patch(PolygonPatch(Point(m(minx, maxy)).buffer(5), fc='#ffffff', ec='#ffffff', alpha=1, zorder=5))
        # upper right corner(lon:maxX, lat:maxY)
        ax.add_patch(PolygonPatch(Point(m(maxx, maxy)).buffer(5), fc='#ffffff', ec='#ffffff', alpha=1, zorder=5))
        # lower right corner(lon:maxX, lat:minY)
        ax.add_patch(PolygonPatch(Point(m(maxx, miny)).buffer(5), fc='#ffffff', ec='#ffffff', alpha=1, zorder=5))
        # center point, just to make sure
        ax.add_patch(
            PolygonPatch(Point(m(interestPointLon, interestPointLat)).buffer(1), fc='#ffffff', ec='#ffffff', alpha=1,
                         zorder=5))

    ax.set_xlim(min_x, max_x)
    ax.set_ylim(min_y, max_y)
    a = fig.gca()
    a.set_frame_on(False)
    a.set_xticks([]);
    a.set_yticks([])
    plt.axis('off')
    
    #print (os.path.join(DESTINATION_FOLDER_NAME, currentImageName.replace('.tif', '.png')))
    fig.savefig(os.path.join(DESTINATION_FOLDER_NAME, os.path.basename(currentImageName.replace('_GTI.tif', '_GTC.png'))), facecolor="#000000", transparent=False, box_inches='tight', pad_inches=0, dpi=1)

    plt.close('all')


if __name__ == '__main__':
    datasetType = ['topcoder_1']
    for currentDataset in datasetType:
        # training
        currentGeoTiffFolder = settings['preprocessing']['norm']['GTI_LOCATION'] + '/*.tif'
        
        current_images = glob.glob(currentGeoTiffFolder)

        for currentFeature in SAVED_FEATURE_IDS[0]:
            DESTINATION_FOLDER_NAME = settings['preprocessing']['norm']['GTC_WATER_LOCATION']
            p = mp.Pool(1)
            p.map(main, current_images)
