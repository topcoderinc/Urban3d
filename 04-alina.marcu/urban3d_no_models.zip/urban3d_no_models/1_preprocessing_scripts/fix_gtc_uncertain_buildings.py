import os
import cv2 as cv
import numpy as np
from PIL import Image
import skimage
import time
import sys

DATASET_NAME = sys.argv[1]

GTC_LOCATION = os.path.join(DATASET_NAME, 'gtc/original')
RGB_LOCATION = os.path.join(DATASET_NAME, 'rgb/original')

FIXED_GTC_LOCATION = GTC_LOCATION # overwrite



if not os.path.exists(FIXED_GTC_LOCATION):
    os.makedirs(FIXED_GTC_LOCATION)

paths = (os.path.join(root, filename)
         for root, _, filenames in os.walk(GTC_LOCATION)
         for filename in filenames)

for current_image_path in paths:
    current_image_PIL = Image.open(current_image_path)
    current_image = np.array(current_image_PIL)
    
    time.sleep(0.1)
    
    current_image3 = cv.imread(os.path.join(RGB_LOCATION, os.path.basename(current_image_path.replace('_GTC.png', '_RGB.tif'))), 0)

    current_image3_no_data_locations = np.equal(current_image3,0)

    current_image[current_image3_no_data_locations]= 0
    
    cv.imwrite(os.path.join(FIXED_GTC_LOCATION, os.path.basename(current_image_path)), current_image)

    
