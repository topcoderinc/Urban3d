import os
import cv2 as cv
import numpy as np
from PIL import Image
import skimage
from skimage import morphology
import multiprocessing as mp
from skimage.measure import label
from skimage.color import label2rgb
from skimage.measure import regionprops
import yaml 
import sys
SETTINGS_FILENAME = 'settings.yaml'

with open(SETTINGS_FILENAME, 'r') as f:
    settings = yaml.load(f)

STAGE = sys.argv[1]

DSM_LOCATION= settings[STAGE]['norm']['DSM_LOCATION']
DTM_LOCATION= settings[STAGE]['norm']['DTM_LOCATION']
RGB_LOCATION= settings[STAGE]['norm']['RGB_LOCATION']

DSM2RGB_LOCATION= settings[STAGE]['norm']['DMD_LOCATION'] 

DSM_NO_VALUE = -32000

LOWER_BOUND = -20
UPPER_BOUND = 30 #180 #no clipping # 30 better clipping

WATER_THRESHOLD = 125

MIN_WATER_AREA = 1000

if not os.path.exists(DSM2RGB_LOCATION):
    os.makedirs(DSM2RGB_LOCATION)

paths = (os.path.join(root, filename)
         for root, _, filenames in os.walk(DSM_LOCATION)
         for filename in filenames)

def process_file(current_image_path):
    current_image_PIL = Image.open(current_image_path)
    current_image = np.array(current_image_PIL)
    current_image_PIL2 = Image.open(os.path.join(DTM_LOCATION, os.path.basename(current_image_path.replace('DSM', 'DTM'))))
    current_image2 = np.array(current_image_PIL2)
    current_image_rgb = cv.imread(os.path.join(RGB_LOCATION, os.path.basename(current_image_path.replace('_DSM.tif', '_RGB.tif'))), 1)
    current_image3 = current_image_rgb[:,:,0]
    current_image3_no_data_locations = np.equal(current_image3,0)

    current_image -=current_image2 # this makes dsm-dtm 0 @ -32k

    # clip dsm-dtm
    current_image[np.less(current_image, LOWER_BOUND)] = LOWER_BOUND
    current_image[np.greater(current_image, UPPER_BOUND)] = UPPER_BOUND
    
    # remove missing areas from rgb
    current_image[current_image3_no_data_locations] = LOWER_BOUND
    
    current_image = (current_image  - LOWER_BOUND) / (UPPER_BOUND - LOWER_BOUND + np.spacing(1))
    
    np.save(os.path.join(DSM2RGB_LOCATION, os.path.basename(current_image_path.replace('_DSM.tif', '_DMD.npy'))), current_image)
    current_image *= 255
    cv.imwrite(os.path.join(DSM2RGB_LOCATION, os.path.basename(current_image_path.replace('_DSM.tif', '_DMD.png'))), current_image)
    
p = mp.Pool(8)
p.map(process_file, paths)
    
