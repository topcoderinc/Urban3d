#!/usr/bin/env python
# -*- coding: utf-8 -*-

import shutil
import os
import glob
import numpy as np
import cv2 as cv
import json
import argparse
import h5py
import scipy.misc
import math
from PIL import Image
import sys
import yaml 

SETTINGS_FILENAME = 'settings.yaml'

with open(SETTINGS_FILENAME, 'r') as f:
    settings = yaml.load(f)

CROP_SIZE = 1024

DATASET_NAME = sys.argv[1]

STRIDE = int(sys.argv[2])

DATASET_SUBTYPES = ['rgb', 'gtc', 'dmd']

def slice_dataset_fixed_stride (input_dir, output_dir, dataset_subtype):

    if os.path.exists(output_dir):
        shutil.rmtree(output_dir)

    os.makedirs(output_dir)

    # get filenames
    input_fns = np.asarray(sorted(glob.glob('%s/*%s' % (input_dir, INPUT_EXTENSION))))

    n_all_files = len(input_fns)
    n_patches = 0
    
    for file_i, fn in enumerate(input_fns):
        
        if dataset_subtype == 'rgb':
            current_image_PIL = Image.open(fn)
            im = np.array(current_image_PIL)
        elif dataset_subtype == 'gtc':
            current_image_PIL = Image.open(fn).convert('L')
            im = np.array(current_image_PIL)   
        else:
            im = np.load(fn)
        
        im_name = os.path.basename(fn)
        if dataset_subtype == 'rgb':
            rows, cols, _ = im.shape
        else:
            rows, cols = im.shape
        
        uvnp = rows / CROP_SIZE
        uhnp = cols / CROP_SIZE
        vnp = math.floor(uvnp)
        hnp = math.floor(uhnp)
        
        paddedRows = (vnp + 1) * CROP_SIZE
        paddedCols = (hnp + 1) * CROP_SIZE
        
        deltaPaddedHorizontal = paddedCols - cols
        deltaPaddedVertical = paddedRows - rows

        padded_img = cv.copyMakeBorder(im, 0, int(deltaPaddedVertical), 0, int(deltaPaddedHorizontal), cv.BORDER_CONSTANT, 0)
        
        name = im_name[:-4]
        
        start_indices_width = np.asarray(range(0, cols, STRIDE))
        start_indices_height = np.asarray(range(0, rows, STRIDE))
        total_width = start_indices_width[-1]+CROP_SIZE
        total_height = start_indices_height[-1]+CROP_SIZE
        reminder_width = total_width - cols
        reminder_height = total_height - rows
        reminder_width /= len(start_indices_width)-1
        reminder_height /= len(start_indices_height)-1

        for idx in range(len(start_indices_width)):
            start_indices_width[idx] = start_indices_width[idx] - idx*reminder_width
        for idx in range(len(start_indices_height)):
            start_indices_height[idx] = start_indices_height[idx] - idx*reminder_height

        start_indices_width[-1] = cols - CROP_SIZE
        start_indices_height[-1] = rows - CROP_SIZE
        
        for rowPointer in start_indices_width:
            for columnPointer in start_indices_height:

                # rgb patch
                patch = padded_img[rowPointer:rowPointer + CROP_SIZE, columnPointer:columnPointer + CROP_SIZE]
                
                if dataset_subtype == 'rgb' or dataset_subtype == 'gtc':
                    cv.imwrite(os.path.join(output_dir, name + '_' + str(rowPointer + 1) + '_' + str(columnPointer + 1) + OUTPUT_EXTENSION), patch)
                else:
                    np.save(os.path.join(output_dir, name + '_' + str(rowPointer + 1) + '_' + str(columnPointer + 1) + OUTPUT_EXTENSION), patch)
                
if __name__ == '__main__':
    for current_dataset_subtype in DATASET_SUBTYPES:
        INPUT_FOLDER = os.path.join(DATASET_NAME, current_dataset_subtype, 'original')
        OUTPUT_FOLDER = os.path.join(DATASET_NAME, current_dataset_subtype, 'patches_stride_' +str(STRIDE))
        if current_dataset_subtype == 'rgb':
            # For RGB
            INPUT_EXTENSION = '.tif'
            OUTPUT_EXTENSION = '.tif'
        elif current_dataset_subtype == 'gtc':
            # For GTC
            INPUT_EXTENSION = '.png'
            OUTPUT_EXTENSION = '.png'
        elif current_dataset_subtype == 'dmd':
            # For DSM
            OUTPUT_EXTENSION = '.npy'
            INPUT_EXTENSION = '.npy'
        
        slice_dataset_fixed_stride(INPUT_FOLDER, OUTPUT_FOLDER, current_dataset_subtype)
                                               
                                               
