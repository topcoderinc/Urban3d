import os
import cv2 as cv
import numpy as np
from PIL import Image
import skimage
from skimage.measure import label
from skimage.color import label2rgb
from skimage.measure import regionprops
from sklearn.metrics import jaccard_similarity_score
import multiprocessing as mp
import sys
import yaml 

SETTINGS_FILENAME = 'settings.yaml'

with open(SETTINGS_FILENAME, 'r') as f:
    settings = yaml.load(f)

NN_OUTPUT_LOCATION = sys.argv[1]

GT_LOCATION = settings['preprocessing']['norm']['GTC_LOCATION'] #'/nvme-nets/misc/topcoder/data/dataset_20171203_corrected/GTC_ALL_236/GTC_uncertain_fixed_ALL_174/original'
# overwrite
OUTPUT_LOCATION = GT_LOCATION  

MIN_JACCARD_SCORE = 0.1

MIN_HOUSE_SIZE = 100

paths = (os.path.join(root, filename)
         for root, _, filenames in os.walk(NN_OUTPUT_LOCATION)
         for filename in filenames)
         
if not os.path.exists(OUTPUT_LOCATION):
    os.makedirs(OUTPUT_LOCATION)

def process_file(current_nn_path):
    current_nn_image = cv.imread(current_nn_path, 0)
    failures_image = np.zeros_like(current_nn_image)
    true_positives = 0 
    false_positives = 0
    false_negatives = 0
    # no gt >> only nn gt
    try:    
        current_gt_image = cv.imread(os.path.join(GT_LOCATION, os.path.basename(current_nn_path.replace('.png', '_GTC.png'))), 0)/255
        cs = current_gt_image.shape
    except:
        cv.imwrite(os.path.join(OUTPUT_LOCATION, os.path.basename(current_nn_path.replace('.png', '_GTC.png'))), current_nn_image)
        return

    
    nn_labeled = label(current_nn_image, background=0)
    gt_labeled = label(current_gt_image, background=0)
    final_gt = np.zeros_like(current_nn_image)
    added_nn_houses = np.zeros_like(current_nn_image)
    
    # remove gt
    os.remove(os.path.join(GT_LOCATION, os.path.basename(current_nn_path.replace('.png', '_GTC.png'))))
    
    for region in regionprops(nn_labeled):
        # find best match - probably the most wasteful stuff coded today
        nn_with_current_region = np.zeros_like(current_nn_image)
        nn_with_current_region[region.bbox[0]:region.bbox[2], region.bbox[1]:region.bbox[3]] = region.image
        gt_with_current_region_sum = current_gt_image + nn_with_current_region

        overlapping_regions = np.greater(gt_with_current_region_sum, 1)
        
        if np.count_nonzero(overlapping_regions):
            overlapping_regions_labeled =label(overlapping_regions, background=0)
            overlapping_regions = regionprops(overlapping_regions_labeled)
            areas = [r.area for r in overlapping_regions]
            idx = np.argsort(areas)
            largest_region = overlapping_regions[idx[-1]]
            gt_with_largest_overlapping_region = np.zeros_like(current_nn_image)
            gt_with_largest_overlapping_region[largest_region.bbox[0]:largest_region.bbox[2], largest_region.bbox[1]:largest_region.bbox[3]] = largest_region.image
            gt_with_building = np.zeros_like(current_nn_image, dtype=np.uint8)
            building_label_int = gt_labeled[largest_region.coords[0,0], largest_region.coords[0,1]]
            gt_with_building += np.equal(gt_labeled,building_label_int)
            intersection = np.minimum(nn_with_current_region, gt_with_largest_overlapping_region)
            union = np.maximum(nn_with_current_region, gt_with_largest_overlapping_region)
            score = np.sum(intersection) / np.sum(union)

            if score > MIN_JACCARD_SCORE:
                true_positives += 1
                final_gt += gt_with_building
            else:
                false_positives += 1
            # remove largest overlapping region from gt
            current_gt_image -= gt_with_largest_overlapping_region
        else:
            if np.count_nonzero(nn_with_current_region) > MIN_HOUSE_SIZE:
                final_gt += nn_with_current_region
                added_nn_houses += nn_with_current_region

    cv.imwrite(os.path.join(OUTPUT_LOCATION, os.path.basename(current_nn_path.replace('.png', '_GTC.png'))), final_gt * 255)

p = mp.Pool(8)
p.map(process_file, paths)

        
    

