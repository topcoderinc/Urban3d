#!/usr/bin/env bash

nvidia-docker build -t albu .
