#!/usr/bin/env bash

nvidia-docker run -v /mnt/disk2/urban3d:/data --rm -ti --ipc=host albu